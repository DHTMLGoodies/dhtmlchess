<img src="<?php echo plugins_url( $this->plugin_name . "/", $this->plugin_name ); ?>/assets/banner-772x250.png">
<h1><?php echo __("WordPressChess PRO", $this->plugin_name); ?></h1>
<h2><?php echo __("Upgrade to PRO version to unlock these features", $this->plugin_name); ?>:</h2>
<ul>
    <li><a href="https://wordpresschess.com/play-computer/" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Play computer mode (StockfishJS)", $this->plugin_name); ?></a></li>
    <li><a href="https://wordpresschess.com/tactic-puzzles/" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Tactic Puzzles", $this->plugin_name); ?></a></li>
    <li><a href="https://wordpresschess.com/the-immortal-game/" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Show games from database with the [chess] shortcode", $this->plugin_name); ?></a></li>
    <li><a href="https://wordpresschess.com/wordpress-chess-for-opening-training/" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Opening training", $this->plugin_name); ?></a></li>
    <li><a href="https://wordpresschess.com/game-viewer-computer-mode/" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Play computer from any game position", $this->plugin_name); ?></a></li>
    <li><a href="https://dhtmlchess.com/forums" onclick="var w=window.open(this.href);w.focus();return false"><?php echo __("Access to Priority Support forum", $this->plugin_name); ?></a></li>
    <li><?php echo __("Ad Free", $this->plugin_name); ?></li>
</ul>

<button class="button button-primary button-large" onclick="var w = window.open('https://wordpresschess.com/pro-version');w.focus()"><?php echo __("Upgrade Now", $this->plugin_name) ?></button>