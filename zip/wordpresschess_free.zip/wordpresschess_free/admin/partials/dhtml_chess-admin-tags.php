<?php
wp_enqueue_style($this->plugin_name . "css", plugin_dir_url(__FILE__) . '../../api/css/dhtml-chess-all.css', array(), $this->version, 'all');
wp_enqueue_script($this->plugin_name . "js", plugin_dir_url(__FILE__) . '../../api/js/dhtml-chess-minified.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "not-tbl", plugin_dir_url(__FILE__) . '../../api/src/view/notation/table.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "not-lm", plugin_dir_url(__FILE__) . '../../api/src/view/notation/last-move.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "stockfish", plugin_dir_url(__FILE__) . '../../api/src/controller/stockfish-engine-controller.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "editor", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-editor-minified.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates1", plugin_dir_url(__FILE__) . '../../api/src/wp-public/wordpress-templates-minified.js', array(), $this->version, false);
wp_enqueue_style($this->plugin_name . "css-overrides", plugin_dir_url(__FILE__) . '../../api/themes/overrides.css', array(), $this->version, 'all');

$options = get_option($this->plugin_name);
$theme = isset($options["theme"]) ? $options["theme"] : "wood1";

require_once(plugin_dir_path(__FILE__) . '../../api/autoload.php');

?>

<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <script type="text/javascript">

        var docRoot = '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>';

        var currentThemeCss;
        var currentThemeJs;
        var currentThemeName;

        function loadTheme(theme) {
            currentThemeName = theme;
            if (currentThemeCss != undefined) {
                currentThemeCss.remove();
            }
            currentThemeCss = jQuery('<link/>', {
                rel: 'stylesheet',
                type: 'text/css',
                href: docRoot + '/themes/' + theme + '.css?rnd=' + Math.random()
            });
            currentThemeCss.appendTo('head');

            var pr = jQuery('#preview')[0];
            pr.className = 'dc-' + theme;

            jQuery.ajax({
                url: docRoot + '/themes/' + theme + '.js',
                dataType: "script",
                success: function () {

                    if (currentTag) {
                        loadPreview(currentTag);

                    }
                }
            });

        }

        jQuery(document).ready(function () {
            loadTheme('<?php echo $theme; ?>');
        });


        //
    </script>

    <?php
    $themes = DhtmlChessViews::getThemes();
    $tags = DhtmlChessViews::getAvailableTags();
    $allAttributes = DhtmlChessViews::getAllAttributes();
    ?>
    <script type="text/javascript">
        var tags = <?php echo json_encode($tags); ?>;
    </script>
    <h4><?php echo esc_html("Select from the list below to see preview of the templates and the tags you can use in your posts."); ?></h4>

    <fieldset class="dhtml-chess-admin-fieldset">
        <legend>Select shortcode</legend>

        <p>
            <select id="dhtml-chess-tag">
                <?php
                foreach ($tags as $index => $tag) {
                    echo '<option value="' . $index . '">' . $tag["title"] . '</option>';
                }
                ?>
            </select> <span id="tag-preview-top"></span>

        </p>
        <p>
            <script type="text/javascript">
                var defaultTheme = '<?php echo $theme; ?>';
            </script>

            <select id="dhtml-chess-theme">
                <option value="">Use default theme</option>
                <?php
                foreach ($themes as $th) {
                    $key = $th[0];
                    $val = $th[1];
                    echo '<option value="' . $key . '">' . $val . '</option>';
                }
                ?>
            </select>
        </p>
    </fieldset>
    <br>

    <script type="text/javascript">
        jQuery('#dhtml-chess-theme').on('change', function () {
            var val = jQuery('#dhtml-chess-theme option:selected').val();
            if (val.length > 0) {
                loadTheme(val);
            } else {
                loadTheme('<?php echo $theme; ?>')
            }

        });

        jQuery('#dhtml-chess-tag').on('change', function () {
            var val = jQuery('#dhtml-chess-tag option:selected').val();
            var tag = tags[val];
            loadPreview(tag);


        });

        var currentTag;

        function loadPreview(tag) {

            currentTag = tag;

            jQuery("#preview").empty();

            if (tag.type) {

                jQuery('#heading').html(tag.title);
                jQuery('#desc').html(tag.desc);
                jQuery('#help').show();
                var options;
                ludo.config.setUrl(window.ajaxurl);

                if(tag.type == 'standings_table'){
                    jQuery.ajax({
                        method:'post',
                        url: ludo.config.getUrl(),
                        data:{
                            action:'get_standings_html',
                            pgn : 4
                        },
                        dataType: "html",
                        complete: function (response, status) {
                            if(status == 'success'){
                                jQuery("#preview").html(response.responseText);
                            }
                        }
                    });
                    updateTag();
                    return;
                }

                if(tag.type == 'standings_grid'){
                    options = getStandingsGridOptions();
                }

                if (tag.type == 'g') {
                    options = getDefaultGameOptions();
                }
                if (tag.type == 'p') {
                    options = getDefaultPgnOptions();
                }
                if(tag.type=='tournament'){
                    options = getDefaultTournamentOptions();
                }

                if (tag.type == 't') {
                    options = getDefaultTacticOptions();
                }
                if (tag.type == 'fen') {
                    options = getDefaultFenOptions();
                }
                if (tag.type == 'pgn') {
                    options = getDefaultPgnStaticOptions();
                    tag.script = 'WPGame1';
                }
                if(tag.type == 'comp'){
                    options = getDefaultCompPlayOptions();
                }
                var view = new chess[tag.script](options);
                if(tag.pro && view.boardId){
                    var parent = ludo.$(view.boardId);
                    var v = jQuery('<div style="z-index:1000;position:absolute;width:100%;height:100%;background-repeat:no-repeat;background-position:center center"></div>');
                    v.css('background-image', 'url(<?php echo plugins_url( $this->plugin_name . "/api/", $this->plugin_name ); ?>/images/pro_feature.png)');
                    parent.boardEl().append(v);
                }
                updateTag();
            }

        }



        function updateTag() {
            jQuery('#tag-container').show();


            jQuery('#replaceText').html(currentTag.help || '');
            var html = '[' + currentTag.shortcode;


            var attr = currentTag.attributes || {};

            if (currentThemeName != defaultTheme) {
                attr.theme = currentThemeName;
            }

            jQuery.each(attr, function (key, val) {
                var sep = jQuery.type(val) == 'string' ? '"' : '';
                html += ' ' + key + '=' + sep + val + sep;


            });


            html += ']';

            if(currentTag.enclosing){
                html += currentTag.enclosing + '[/' + currentTag.shortcode + ']';
            }

            jQuery('#replaceText').html(currentTag.help);


            jQuery('#tag').html(html);
            jQuery('#tag-preview-top').html(html);
        }


        function getStandingsTable(){
            return {


            }

        }

        function getDefaultFenOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                fen: "2r2rk1/2q2p1p/6pQ/4P1N1/8/8/PPP5/2KR4 w - - 0 1"
            }

        }

        function getDefaultCompPlayOptions(){
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                isPreview:true
            }

        }

        function getDefaultTacticOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 2,
                    name: 'Tactics'
                }
            }
        }

        function getDefaultGameOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                gameId: 2
            }
        }

        function getStandingsGridOptions(){
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 4
                }
            }

        }

        function getDefaultPgnOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 1,
                    name: 'Great Games'
                }
            }
        }

        function getDefaultTournamentOptions(){
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 3,
                    name: 'Great Games'
                }
            }

        }


        function getDefaultPgnStaticOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                model: {
                    "metadata": {"castle": 1},
                    "event": "Immortal game",
                    "site": "London",
                    "date": "1851.??.??",
                    "round": "?",
                    "white": "Anderssen,A",
                    "black": "Kieseritzky,L",
                    "result": "1-0",
                    "fen": "rnbqkbnr\/pppppppp\/8\/8\/8\/8\/PPPPPPPP\/RNBQKBNR w KQkq - 0 1",
                    "moves": [{
                        "m": "e4",
                        "from": "e2",
                        "to": "e4",
                        "fen": "rnbqkbnr\/pppppppp\/8\/8\/4P3\/8\/PPPP1PPP\/RNBQKBNR b KQkq e3 0 1"
                    }, {
                        "m": "e5",
                        "from": "e7",
                        "to": "e5",
                        "fen": "rnbqkbnr\/pppp1ppp\/8\/4p3\/4P3\/8\/PPPP1PPP\/RNBQKBNR w KQkq e6 0 2"
                    }, {
                        "m": "f4",
                        "from": "f2",
                        "to": "f4",
                        "fen": "rnbqkbnr\/pppp1ppp\/8\/4p3\/4PP2\/8\/PPPP2PP\/RNBQKBNR b KQkq f3 0 2"
                    }, {
                        "m": "exf4",
                        "from": "e5",
                        "to": "f4",
                        "fen": "rnbqkbnr\/pppp1ppp\/8\/8\/4Pp2\/8\/PPPP2PP\/RNBQKBNR w KQkq - 0 3"
                    }, {
                        "m": "Bc4",
                        "from": "f1",
                        "to": "c4",
                        "fen": "rnbqkbnr\/pppp1ppp\/8\/8\/2B1Pp2\/8\/PPPP2PP\/RNBQK1NR b KQkq - 1 3"
                    }, {
                        "m": "Qh4+",
                        "from": "d8",
                        "to": "h4",
                        "fen": "rnb1kbnr\/pppp1ppp\/8\/8\/2B1Pp1q\/8\/PPPP2PP\/RNBQK1NR w KQkq - 2 4"
                    }, {
                        "m": "Kf1",
                        "from": "e1",
                        "to": "f1",
                        "fen": "rnb1kbnr\/pppp1ppp\/8\/8\/2B1Pp1q\/8\/PPPP2PP\/RNBQ1KNR b kq - 3 4"
                    }, {
                        "m": "b5",
                        "from": "b7",
                        "to": "b5",
                        "fen": "rnb1kbnr\/p1pp1ppp\/8\/1p6\/2B1Pp1q\/8\/PPPP2PP\/RNBQ1KNR w kq b6 0 5"
                    }, {
                        "m": "Bxb5",
                        "from": "c4",
                        "to": "b5",
                        "fen": "rnb1kbnr\/p1pp1ppp\/8\/1B6\/4Pp1q\/8\/PPPP2PP\/RNBQ1KNR b kq - 0 5"
                    }, {
                        "m": "Nf6",
                        "from": "g8",
                        "to": "f6",
                        "fen": "rnb1kb1r\/p1pp1ppp\/5n2\/1B6\/4Pp1q\/8\/PPPP2PP\/RNBQ1KNR w kq - 1 6"
                    }, {
                        "m": "Nf3",
                        "from": "g1",
                        "to": "f3",
                        "fen": "rnb1kb1r\/p1pp1ppp\/5n2\/1B6\/4Pp1q\/5N2\/PPPP2PP\/RNBQ1K1R b kq - 2 6"
                    }, {
                        "m": "Qh6",
                        "from": "h4",
                        "to": "h6",
                        "fen": "rnb1kb1r\/p1pp1ppp\/5n1q\/1B6\/4Pp2\/5N2\/PPPP2PP\/RNBQ1K1R w kq - 3 7"
                    }, {
                        "m": "d3",
                        "from": "d2",
                        "to": "d3",
                        "fen": "rnb1kb1r\/p1pp1ppp\/5n1q\/1B6\/4Pp2\/3P1N2\/PPP3PP\/RNBQ1K1R b kq - 0 7"
                    }, {
                        "m": "Nh5",
                        "from": "f6",
                        "to": "h5",
                        "fen": "rnb1kb1r\/p1pp1ppp\/7q\/1B5n\/4Pp2\/3P1N2\/PPP3PP\/RNBQ1K1R w kq - 1 8"
                    }, {
                        "m": "Nh4",
                        "from": "f3",
                        "to": "h4",
                        "fen": "rnb1kb1r\/p1pp1ppp\/7q\/1B5n\/4Pp1N\/3P4\/PPP3PP\/RNBQ1K1R b kq - 2 8"
                    }, {
                        "m": "Qg5",
                        "from": "h6",
                        "to": "g5",
                        "fen": "rnb1kb1r\/p1pp1ppp\/8\/1B4qn\/4Pp1N\/3P4\/PPP3PP\/RNBQ1K1R w kq - 3 9"
                    }, {
                        "m": "Nf5",
                        "from": "h4",
                        "to": "f5",
                        "fen": "rnb1kb1r\/p1pp1ppp\/8\/1B3Nqn\/4Pp2\/3P4\/PPP3PP\/RNBQ1K1R b kq - 4 9"
                    }, {
                        "m": "c6",
                        "from": "c7",
                        "to": "c6",
                        "fen": "rnb1kb1r\/p2p1ppp\/2p5\/1B3Nqn\/4Pp2\/3P4\/PPP3PP\/RNBQ1K1R w kq - 0 10"
                    }, {
                        "m": "g4",
                        "from": "g2",
                        "to": "g4",
                        "fen": "rnb1kb1r\/p2p1ppp\/2p5\/1B3Nqn\/4PpP1\/3P4\/PPP4P\/RNBQ1K1R b kq g3 0 10"
                    }, {
                        "m": "Nf6",
                        "from": "h5",
                        "to": "f6",
                        "fen": "rnb1kb1r\/p2p1ppp\/2p2n2\/1B3Nq1\/4PpP1\/3P4\/PPP4P\/RNBQ1K1R w kq - 1 11"
                    }, {
                        "m": "Rg1",
                        "from": "h1",
                        "to": "g1",
                        "fen": "rnb1kb1r\/p2p1ppp\/2p2n2\/1B3Nq1\/4PpP1\/3P4\/PPP4P\/RNBQ1KR1 b kq - 2 11"
                    }, {
                        "m": "cxb5",
                        "from": "c6",
                        "to": "b5",
                        "fen": "rnb1kb1r\/p2p1ppp\/5n2\/1p3Nq1\/4PpP1\/3P4\/PPP4P\/RNBQ1KR1 w kq - 0 12"
                    }, {
                        "m": "h4",
                        "from": "h2",
                        "to": "h4",
                        "fen": "rnb1kb1r\/p2p1ppp\/5n2\/1p3Nq1\/4PpPP\/3P4\/PPP5\/RNBQ1KR1 b kq h3 0 12"
                    }, {
                        "m": "Qg6",
                        "from": "g5",
                        "to": "g6",
                        "fen": "rnb1kb1r\/p2p1ppp\/5nq1\/1p3N2\/4PpPP\/3P4\/PPP5\/RNBQ1KR1 w kq - 1 13"
                    }, {
                        "m": "h5",
                        "from": "h4",
                        "to": "h5",
                        "fen": "rnb1kb1r\/p2p1ppp\/5nq1\/1p3N1P\/4PpP1\/3P4\/PPP5\/RNBQ1KR1 b kq - 0 13"
                    }, {
                        "m": "Qg5",
                        "from": "g6",
                        "to": "g5",
                        "fen": "rnb1kb1r\/p2p1ppp\/5n2\/1p3NqP\/4PpP1\/3P4\/PPP5\/RNBQ1KR1 w kq - 1 14"
                    }, {
                        "m": "Qf3",
                        "from": "d1",
                        "to": "f3",
                        "fen": "rnb1kb1r\/p2p1ppp\/5n2\/1p3NqP\/4PpP1\/3P1Q2\/PPP5\/RNB2KR1 b kq - 2 14"
                    }, {
                        "m": "Ng8",
                        "from": "f6",
                        "to": "g8",
                        "fen": "rnb1kbnr\/p2p1ppp\/8\/1p3NqP\/4PpP1\/3P1Q2\/PPP5\/RNB2KR1 w kq - 3 15"
                    }, {
                        "m": "Bxf4",
                        "from": "c1",
                        "to": "f4",
                        "fen": "rnb1kbnr\/p2p1ppp\/8\/1p3NqP\/4PBP1\/3P1Q2\/PPP5\/RN3KR1 b kq - 0 15"
                    }, {
                        "m": "Qf6",
                        "from": "g5",
                        "to": "f6",
                        "fen": "rnb1kbnr\/p2p1ppp\/5q2\/1p3N1P\/4PBP1\/3P1Q2\/PPP5\/RN3KR1 w kq - 1 16"
                    }, {
                        "m": "Nc3",
                        "from": "b1",
                        "to": "c3",
                        "fen": "rnb1kbnr\/p2p1ppp\/5q2\/1p3N1P\/4PBP1\/2NP1Q2\/PPP5\/R4KR1 b kq - 2 16"
                    }, {
                        "m": "Bc5",
                        "from": "f8",
                        "to": "c5",
                        "fen": "rnb1k1nr\/p2p1ppp\/5q2\/1pb2N1P\/4PBP1\/2NP1Q2\/PPP5\/R4KR1 w kq - 3 17"
                    }, {
                        "m": "Nd5",
                        "from": "c3",
                        "to": "d5",
                        "fen": "rnb1k1nr\/p2p1ppp\/5q2\/1pbN1N1P\/4PBP1\/3P1Q2\/PPP5\/R4KR1 b kq - 4 17"
                    }, {
                        "m": "Qxb2",
                        "from": "f6",
                        "to": "b2",
                        "fen": "rnb1k1nr\/p2p1ppp\/8\/1pbN1N1P\/4PBP1\/3P1Q2\/PqP5\/R4KR1 w kq - 0 18"
                    }, {
                        "m": "Bd6",
                        "from": "f4",
                        "to": "d6",
                        "fen": "rnb1k1nr\/p2p1ppp\/3B4\/1pbN1N1P\/4P1P1\/3P1Q2\/PqP5\/R4KR1 b kq - 1 18"
                    }, {
                        "m": "Qxa1+",
                        "from": "b2",
                        "to": "a1",
                        "fen": "rnb1k1nr\/p2p1ppp\/3B4\/1pbN1N1P\/4P1P1\/3P1Q2\/P1P5\/q4KR1 w kq - 0 19"
                    }, {
                        "m": "Ke2",
                        "from": "f1",
                        "to": "e2",
                        "fen": "rnb1k1nr\/p2p1ppp\/3B4\/1pbN1N1P\/4P1P1\/3P1Q2\/P1P1K3\/q5R1 b kq - 1 19"
                    }, {
                        "m": "Bxg1",
                        "from": "c5",
                        "to": "g1",
                        "fen": "rnb1k1nr\/p2p1ppp\/3B4\/1p1N1N1P\/4P1P1\/3P1Q2\/P1P1K3\/q5b1 w kq - 0 20"
                    }, {
                        "m": "e5",
                        "from": "e4",
                        "to": "e5",
                        "fen": "rnb1k1nr\/p2p1ppp\/3B4\/1p1NPN1P\/6P1\/3P1Q2\/P1P1K3\/q5b1 b kq - 0 20"
                    }, {
                        "m": "Na6",
                        "from": "b8",
                        "to": "a6",
                        "fen": "r1b1k1nr\/p2p1ppp\/n2B4\/1p1NPN1P\/6P1\/3P1Q2\/P1P1K3\/q5b1 w kq - 1 21"
                    }, {
                        "m": "Nxg7+",
                        "from": "f5",
                        "to": "g7",
                        "fen": "r1b1k1nr\/p2p1pNp\/n2B4\/1p1NP2P\/6P1\/3P1Q2\/P1P1K3\/q5b1 b kq - 0 21"
                    }, {
                        "m": "Kd8",
                        "from": "e8",
                        "to": "d8",
                        "fen": "r1bk2nr\/p2p1pNp\/n2B4\/1p1NP2P\/6P1\/3P1Q2\/P1P1K3\/q5b1 w - - 1 22"
                    }, {
                        "m": "Qf6+",
                        "from": "f3",
                        "to": "f6",
                        "fen": "r1bk2nr\/p2p1pNp\/n2B1Q2\/1p1NP2P\/6P1\/3P4\/P1P1K3\/q5b1 b - - 2 22"
                    }, {
                        "m": "Nxf6",
                        "from": "g8",
                        "to": "f6",
                        "fen": "r1bk3r\/p2p1pNp\/n2B1n2\/1p1NP2P\/6P1\/3P4\/P1P1K3\/q5b1 w - - 0 23"
                    }, {
                        "m": "Be7+",
                        "from": "d6",
                        "to": "e7",
                        "fen": "r1bk3r\/p2pBpNp\/n4n2\/1p1NP2P\/6P1\/3P4\/P1P1K3\/q5b1 b - - 1 23"
                    }],
                    "id": 2,
                    "pgn": "Great Games",
                    "pgn_id": "1"
                }
            }
        }


    </script>

    <h3 id="heading" style="display:none"></h3>
    <h4 id="desc" style="display:none"></h4>
    <h1><?php echo __("Preview"); ?></h1>

    <div id="preview" style="max-width:500px;margin-top:10px"></div>
    <div id="help" style="display:none"><em><?php echo __("The fonts in the preview may appear different on your website depending on your css styles"); ?>.</em></div>



    <fieldset id="tag-container" style="display:none" class="dhtml-chess-admin-fieldset">
        <legend><?php echo __("Usage"); ?></legend>
            <p><?php echo __("To use this board, insert the tag below into your posts"); ?>:</p>
            <p><?php echo esc_html("Tag Example"); ?>: <span id="tag"
                          style="display:inline-block;border-radius:5px;padding:5px;background-color:#666;color:#fff"></span>
            </p>
            <p id="replaceText"><?php echo __("Replace the value inside the angle brackets with the numeric id found in the game editor"); ?>.</p>

            <h4><?php echo __("Optional attributes"); ?>:</h4>
            <table>
                <?php

                foreach($allAttributes as $key=>$attr){
                    echo "<tr style='vertical-align: top'><td><strong>" . $key  ."</strong></td>";
                    echo "<td>". $attr["desc"]. "</td></tr>";
                    echo "<tr><td></td><td><em>" . __("Example") . ": ". $attr["example"]."</em></td>";
                    echo "</tr>";
                }

                ?>
            </table>
    </fieldset>
</div>