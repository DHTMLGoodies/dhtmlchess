<?php
if ( isset( $_GET['m'] ) )
{
	?>
    <div id='message' class='updated fade'><p><strong><?php echo __("PGN successfully imported into"); ?> <?php echo $_GET['m']; ?> (ID: <?php echo $_GET["pgn_id"]; ?>).</strong></p></div>
	<?php
}
if ( isset( $_GET['e'] ) )
{
	?>
    <div id='message' class='error fade'><p><strong><?php echo __("Could not import selected PGN file"); ?>.</strong></p></div>
	<?php
}

?>
<div class="wrap">
    <script type="text/javascript">
        function disableButton(btn){
            var btn = jQuery('#submit-button');
            var a = function(){
                jQuery('#submit-button').prop("disabled", true);
            };
            setTimeout(a, 100);
            btn.val('<?php echo __("Importing", $this->plugin_name) ?>');

            jQuery('#spinning-wheel').css('visibility', 'visible')

        }

    </script>
    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>

    <form method="post" name="wordpresschess_import_pgn" action="admin-post.php" enctype="multipart/form-data">

        <fieldset class="dhtml-chess-admin-fieldset">
            <legend><?php echo __('Import PGN', $this->plugin_name); ?></legend>

            <input type="hidden" name="action" value="wordpresschess_import_pgn" />
            <input type="file" name="pgn" accept=".pgn"><br>
            <input type="text" name="pgn_title" placeholder="<?php echo __("Optional db name", $this->plugin_name); ?>">
            <p><?php echo __("If name is left empty, the pgn file name will be the name of the database", $this->plugin_name); ?>.</p>


			<?php wp_nonce_field( 'wordpresschess_importpgn', '_nonce_wordpresschess' ); ?>
			<?php submit_button(__('Import', $this->plugin_name), 'primary', 'submit', false, array(
				"onclick" => 'disableButton()', "id" => "submit-button"
			)); ?>
            <img id="spinning-wheel" src="images/spinner.gif" style="visibility:hidden">
            <p><em><?php echo __("For large PGN files, the import may take some time", $this->plugin_name); ?></em></p>

        </fieldset>
    </form>
</div>