<?php
/**
 *
 * admin/partials/wp-cbf-admin-display.php - Don't add this comment
 *
 **/


wp_enqueue_style($this->plugin_name . "css", plugin_dir_url(__FILE__) . '../../api/css/dhtml-chess-all.css', array(), $this->version, 'all');
wp_enqueue_script($this->plugin_name . "js", plugin_dir_url(__FILE__) . '../../api/js/dhtml-chess.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates1", plugin_dir_url(__FILE__) . '../../api/src/wp-public/wordpress-templates-minified.js', array(), $this->version, false);
wp_enqueue_style($this->plugin_name . "css-overrides", plugin_dir_url(__FILE__) . '../../api/themes/overrides.css', array(), $this->version, 'all');



function dhtmlchess_add_piece($pluginName, $type, $checkedPiece)
{
    $extension = strstr($type, "svg") ? "svg" : "png";

    $checked = $checkedPiece == $type;

    $pieces = array(
        'wp', 'wb', 'wn', 'wr', 'wq', 'wk',
        'bp', 'bb', 'bn', 'br', 'bq', 'bk',
    );

    $t = strstr($type, "svg") ? __("svg") : __("bitmap");
    ?>
    <tr>

        <td>
            <input value="<?php echo $type; ?>"
                   type="radio" id="<?php echo $pluginName . $type; ?>-pieces" class="<?php echo $pluginName; ?>-pieces"
                   name="<?php echo $pluginName; ?>[pieces]" <?php if ($checked) echo " checked"; ?>>
        </td>

        <td>
            <label for="<?php echo $pluginName . $type; ?>-pieces"><?php echo $type; ?></label>
        </td>
        <?php
        foreach ($pieces as $piece) {
            ?>
            <td>
                <label for="<?php echo $pluginName . $type; ?>-pieces">
                    <img width="45"
                         src="<?php echo plugins_url($pluginName) . '/api/images/' . $type . '45' . $piece . '.' . $extension; ?>">
                </label>
            </td>
            <?php
        }
        ?>
    </tr>
    <?php
}

function addThemeOptions()
{

}

?>

<script type="text/javascript">

    var docRoot = '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>';


    var currentThemeCss;
    var currentThemeJs;
    var currentThemeName;

    function loadTheme() {
        var theme = jQuery('#<?php echo $this->plugin_name; ?>-theme').val();

        currentThemeName = theme;
        if (currentThemeCss != undefined) {
            currentThemeCss.remove();
        }
        currentThemeCss = jQuery('<link/>', {
            rel: 'stylesheet',
            type: 'text/css',
            href: docRoot + '/themes/' + theme + '.css?rnd=' + Math.random()
        });
        currentThemeCss.appendTo('head');


        jQuery.ajax({
            url: docRoot + '/themes/' + theme + '.js',
            dataType: "script",
            success: function () {
                showPreview(currentThemeName);
            }
        });

    }

    jQuery(document).click(function () {
        jQuery('#theme-preview').hide();
    });

    function showPreview(theme) {

        ludo.config.setDocumentRoot(docRoot);

        var pieceLayout = jQuery('.<?php echo $this->plugin_name; ?>-pieces:checked').val();

        chess.THEME['chess.view.board.Board'].pieceLayout = pieceLayout;

        var pr = jQuery('#theme-preview');

        pr.show();
        pr.empty();

        new chess.view.Chess({
            layout: {
                width: 'matchParent', height: 'matchParent', type: 'fill'
            },
            renderTo: pr,
            cls: 'dc-' + theme,

            children: [{
                type: 'chess.view.board.Board',
                pieceLayout: pieceLayout,
                layout: {
                    width: 'matchParent',
                    height: 'matchParent'
                }
            }]
        });


    }
</script>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <form method="post" name="dhtmlchess_options" action="options.php">
        <?php
        $options = get_option($this->plugin_name);
        do_settings_sections($this->plugin_name);

        $theme = isset($options["theme"]) ? $options["theme"] : "wood1";
        $pieces = isset($options["pieces"]) ? $options["pieces"] : "svg_bw";
        $language = isset($options["language"]) ? $options["language"] : "en";
        $default_game_tpl = isset($options["default_game_tpl"]) ? $options["default_game_tpl"] : 1;
        $default_db_tpl = isset($options["default_db_tpl"]) ? $options["default_db_tpl"] : 1;
        $remove_on_uninstall = isset($options["remove_on_uninstall"]) ? $options["remove_on_uninstall"] : 0;

        $themes = DhtmlChessViews::getThemes();

        $languageArray = array(
            array('en', 'English'),
            array('no', 'Norsk')
        );
        ?>
        <?php settings_fields($this->plugin_name); ?>

        <!--
        <fieldset class="dhtml-chess-admin-fieldset">
            <legend><?php esc_attr_e('Language', $this->plugin_name); ?></legend>
            <table>
                <tr>
                    <td><label for="<?php echo $this->plugin_name; ?>-language"><?php _e('language', $this->plugin_name); ?></label></td>
                    <td>
                        <select name="<?php echo $this->plugin_name; ?>[language]"
                                id="<?php echo $this->plugin_name; ?>-language">
                            <?php
        foreach ($languageArray as $language) {
            $selected = $language[0] == $language ? " selected" : "";
            echo '<option value="' . $language[0] . '" ' . $selected . '>' . $language[1] . '</option>';
        }
        ?>
                        </select>
                    </td>
                </tr>

            </table>
        </fieldset>-->


        <fieldset class="dhtml-chess-admin-fieldset">
            <legend><?php echo __('Default Theme'); ?></legend>
            <table>
                <tr>
                    <td>
                        <div style="position:relative">
                            <div style="left:0;top:20px;position:absolute;width:400px;height:400px"
                                 id="theme-preview"></div>
                            <label
                                for="<?php echo $this->plugin_name; ?>-theme"><?php _e('Theme', $this->plugin_name); ?></label>
                    </td>
</div>
<td>
    <select name="<?php echo $this->plugin_name; ?>[theme]"
            id="<?php echo $this->plugin_name; ?>-theme">
        <?php
        foreach ($themes as $th) {
            $selected = $th[0] == $theme ? " selected" : "";
            echo '<option value="' . $th[0] . '" ' . $selected . '>' . $th[1] . '</option>';
        }
        ?>
    </select>
</td>
<td>
    <div style="position:relative"><a href="#" style="display:inline-block"
                                      onclick="loadTheme();return false"><?php _e("Show Preview", $this->plugin_name); ?></a>
    </div>
</td>
</tr>

</table>
</fieldset>

<!-- remove some meta and generators from the <head> -->
<fieldset class="dhtml-chess-admin-fieldset">
    <legend><?php esc_attr_e('Default Chess Pieces', $this->plugin_name); ?></legend>
    <p><?php _e("The SVG pieces are small Vector based chess pieces.", $this->plugin_name); ?> </p>
    <table>

        <?php
        dhtmlchess_add_piece($this->plugin_name, "svg_bw", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_egg", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_alpha_bw", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_alpha_egg", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_alpha_blue", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_merida", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_chessole", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "svg_chess-7", $pieces);


        dhtmlchess_add_piece($this->plugin_name, "merida", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "meridapale", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "kingdom", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "leipzig", $pieces);
        dhtmlchess_add_piece($this->plugin_name, "smart", $pieces);
        // dhtmlchess_add_piece($this->plugin_name, "svg_darkgrey", $pieces);

        ?>

    </table>
</fieldset>

<fieldset class="dhtml-chess-admin-fieldset">
    <legend><?php esc_attr_e('Default Game Template', $this->plugin_name); ?></legend>
    <p><?php _e("Default template for single games. See shortcodes page for preview.", $this->plugin_name); ?> </p>
    <table> 
        <select id="<?php echo $this->plugin_name; ?>-default_game_tpl" name="<?php echo $this->plugin_name; ?>[default_game_tpl]">
            <?php
            $count = DhtmlChessViews::countGameTemplates();

            for($i=1;$i<=$count;$i++){
                $selected = $default_game_tpl == $i ? " selected" : "";
                echo '<option value="' . $i . '"' . $selected . '>Template ' . $i. '</option>';

            }
            ?>
        </select>
    </table>
</fieldset>
<fieldset class="dhtml-chess-admin-fieldset">
    <legend><?php esc_attr_e('Styling Options', $this->plugin_name); ?></legend>
    <table>
        <tr>
            <?php
            $arrow_styles = isset($options["arrow_styles"]) ? $options["arrow_styles"] : "";

            ?>
            <td><p><label for="<?php echo $this->plugin_name; ?>-arrow_styles"><?php _e("Board arrow styles", $this->plugin_name); ?>:</label></p></td>
            <td><input type="text" size="60" placeholder="Styles separated by semicolon, eg. fill:#f00;stroke:blue" value="<?php echo $arrow_styles; ?>" id="<?php echo $this->plugin_name; ?>-arrow_styles" name="<?php echo $this->plugin_name; ?>[arrow_styles]"</td>
        </tr>
        <tr><td colspan="2"><p>
                    <?php _e("Example:", $this->plugin_name); ?> <em>stroke-width:2;stroke:#f00;stroke-opacity:0.5;fill:#f00;fill-opacity:0.2</em><br>
                    <?php _e("This setting will override default arrow styles set by the theme", $this->plugin_name); ?>.</p>
            </td></tr>
    </table>
</fieldset>


<fieldset class="dhtml-chess-admin-fieldset">
    <legend><?php esc_attr_e('Other Options', $this->plugin_name); ?></legend>
    <table>
        <tr>
            <?php
            $checked = $remove_on_uninstall == 1 ? ' checked' : '';

            ?>
            <td><input type="checkbox"<?php echo $checked; ?> value="1" id="<?php echo $this->plugin_name; ?>-remove_on_uninstall" name="<?php echo $this->plugin_name; ?>[remove_on_uninstall]"</td>
            <td><p><label for="<?php echo $this->plugin_name; ?>-remove_on_uninstall"><?php _e("Remove chess database on uninstall. (Leave this option empty if you want to upgrade to PRO version)", $this->plugin_name); ?></label></p></td>

        </tr>
    </table>
</fieldset>
<!--
<fieldset class="dhtml-chess-admin-fieldset">
    <legend><?php esc_attr_e('Default Database Template', $this->plugin_name); ?></legend>
    <p><?php _e("Default Database(Many games) template. See the shortcodes page for preview.", $this->plugin_name); ?> </p>
    <table>
        <select id="<?php echo $this->plugin_name; ?>-default_db_tpl" name="<?php echo $this->plugin_name; ?>[default_db_tpl]">
            <?php
            $count = DhtmlChessViews::countDbTemplates();

            for($i=1;$i<=$count;$i++){
                $selected = $default_db_tpl == $i ? " selected" : "";
                echo '<option value="' . $i . '"' . $selected . '>Game Template ' . $i. '</option>';

            }
            ?>
        </select>
    </table>
</fieldset>
-->

<?php submit_button(__('Save all changes', $this->plugin_name), 'primary', 'submit', TRUE); ?>

</form>

</div>