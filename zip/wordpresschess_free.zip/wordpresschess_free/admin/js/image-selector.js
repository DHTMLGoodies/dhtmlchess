/**
 * Created by alfmagne1 on 21/04/2017.
 */

chess.ImageSelectorCounter = 0;

chess.ImageSelector = new Class({
    Extends: Events,
    renderTo: undefined,
    nameInForm: undefined,


    images: undefined,
    value: undefined,
    dataFields: undefined,
    visible:false,

    initialize: function (config) {


        jQuery(document.body).on('click', this.autoHide.bind(this));

        config.renderTo = jQuery(config.renderTo);
        this.renderTo = config.renderTo;
        this.nameInForm = config.nameInForm;
        this.dataFields = config.dataFields || {};
        this.images = config.images;

        this.value = config.value || this.images[0];

        config.renderTo.parent().css('position', 'relative');

        this.render();

        chess.ImageSelectorCounter++;

    },

    autoHide:function(e){
        var el = jQuery(e.target);
        if(el.hasClass("wpc-image-selector-popout"))return;
        if(el.hasClass("wpc-image-selector-selected"))return;
        var p = el.closest('.wpc-image-selector-popout');
        if(p.length == 0){
            this.hide();
        }
    },

    render: function () {

        var input = this.input = jQuery('<input type="hidden">');
        input.attr('name', this.nameInForm);
        input.val(this.value);
        jQuery.each(this.dataFields, function (key, val) {
            input.data(key, val);
        });


        this.imageDiv = jQuery('<div class="wpc-image-selector-selected"></div>');
        this.imageDiv.on('click', this.togglePopout.bind(this));
        this.renderTo.append(this.imageDiv);

        this.renderTo.append(input);

        this.val(this.value);
    },

    hide:function(){
        if(!this.popout)return;
        this.popout.hide();
        this.visible = false;
    },

    togglePopout:function(){
        if(this.popout == undefined){
            this.popout = jQuery('<div class="wpc-image-selector-popout"></div>');
            this.popoutInner = jQuery('<div class="wpc-image-selector-popout-container"></div>').appendTo(this.popout);
            this.renderTo.append(this.popout);
            this.popout.css('top', this.imageDiv.position().top + this.imageDiv.height());
            this.popout.css('left', this.imageDiv.position().left);

            var that = this;
            jQuery.each(this.images, function(i, image){
                var div = jQuery('<div class="wpc-image-selector-image"></div>');
                div.css('background-image', 'url(' + image.image + ')');
                div.data("val", image.value);
                var fn = function(){
                    that.val(image);
                    that.hide();
                };
                div.on('click', fn);

                this.popoutInner.append(div);
            }.bind(this));

            this.popoutInner.append('<div style="clear:both"></div>');

        }

        if(this.visible){
            this.popout.hide();
        }else{
            this.popout.show();
        }

        this.visible = !this.visible;
    },

    val: function (val) {
        if (arguments.length === 0)return this.selectedImage;
        this.selectedImage = val;

        this.input.val(val.value);

        this.imageDiv.css('background-image', 'url(' + val.image + ')');

        this.fireEvent('change', this.input[0]);
    }
});