var WordPressChessEditorDialog = (function () {
    function _D(editor) {
        this.editor = editor;
    }

    _D.prototype.create = function () {


    };

    return _D;
}());


(function () {
    tinymce.create('tinymce.plugins.wordpresschessfree', {

        editor: undefined,
        dialog: undefined,
        url: undefined,
        currShortCode: undefined,


        tabContents: undefined,
        contentContainer: undefined,
        /**
         * Initializes the plugin, this will be executed after the plugin has been created.
         * This call is done before the editor instance has finished it's initialization so use the onInit event
         * of the editor instance to intercept that event.
         *
         * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
         * @param {string} url Absolute URL to where the plugin is located.
         */
        init: function (ed, url) {
            ed.addButton('chess', {
                title: 'Chess Shortcode',
                cmd: 'chess',
                image: url + '/editor-button.png'
            });
            this.editor = ed;
            this.url = url;
            ed.addCommand('chess', function () {
                this.showDialog();
            }.bind(this));
        },

        showDialog: function () {
            this.getDialog();
        },


        getDialog: function () {
            if (this.dialog === undefined) {
                this.dialog = jQuery('<div class="wpc-mce-dialog"></div>');
                jQuery(document.body).append(this.dialog);

                this.dialog.css('margin-left', -(this.dialog.width() / 2));
                this.dialog.css('margin-top', -(this.dialog.height() / 2));

                var header = jQuery('<div class="wpc-mce-dialog-header">WordPressChess</div>');
                this.dialog.append(header);

                var cl = jQuery('<div class="wpc-mce-close-button"></div>');
                cl.on('mouseenter', function () {
                    cl.addClass('wpc-mce-close-button-over');
                });
                cl.on('mouseleave', function () {
                    cl.removeClass('wpc-mce-close-button-over');
                });
                cl.on('click', this.hideDialog.bind(this));

                header.append(cl);

                this.dialog.append(this.getTabStrip());

                this.contentContainer = jQuery('<div class="wpc-mce-tab-content"></div>');
                this.dialog.append(this.contentContainer);

                var buttonRow = jQuery('<div class="wpc-mce-dialog-buttonrow"></div>');
                this.dialog.append(buttonRow);
                var buttonRowInner = jQuery('<div></div>');
                buttonRow.append(buttonRowInner);


                var insertButton = jQuery('<button class="button button-default">Insert</button>');
                buttonRowInner.append(insertButton);
                insertButton.on('click', this.insertShortCode.bind(this));
                this.showTab('fen');
            }

            this.dialog.show();
            return this.dialog;

        },

        insertShortCode: function () {
            var code = this.getShortCode();
            this.editor.execCommand('mceInsertContent', 0, code);
            this.hideDialog();
        },

        getTabStrip: function () {
            var ts = jQuery('<div class="wpc-mce-tabstrip"></div>');
            ts.append(jQuery('<div class="wpc-mce-tabstrip-line"></div>'));

            var fen = this.getTab('fen');
            ts.append(fen);

            var pgn = this.getTab('pgn');
            ts.append(pgn);
            //var chess = this.getTab('chess');
            //ts.append(chess);

            return ts;
        },

        getTab: function (title) {
            var tab = jQuery('<div class="wpc-mce-tabstrip-tab">' + title + '</div>');
            tab.attr("id", "wpc-tab-" + title);
            var fn = function () {
                this.showTab(title);
            }.bind(this);
            tab.on('click', fn);
            return tab;

        },
        activeTab: undefined,

        showTab: function (title) {
            if (this.activeTab !== undefined) {
                this.activeTab.removeClass('wpc-mce-tabstrip-active');
            }
            var el = jQuery('#wpc-tab-' + title);
            el.addClass('wpc-mce-tabstrip-active');
            this.activeTab = el;

            this.currShortCode = title;

            this.showTabContent(title);
        },

        activeTabContent: undefined,

        showTabContent: function (title) {
            if (this.activeTabContent) {
                this.activeTabContent.hide();
            }

            var content = this.getTabContents(title);
            this.activeTabContent = content;
            content.show();
        },

        getTabContents: function (title) {
            if (this.tabContents === undefined) {
                this.tabContents = {};
            }
            if (this.tabContents[title] === undefined) {
                var content;

                switch (title) {
                    case 'fen':
                        content = this.getFenContent();
                        break;
                    case 'pgn':
                        content = this.getPgnContent();
                        break;
                    default:
                        content = this.getChessContent();
                        break;

                }

                this.tabContents[title] = content;
                this.contentContainer.append(content);

            }
            return this.tabContents[title];
        },

        hideDialog: function () {
            this.dialog.hide();
        },

        getShortCode: function () {
            switch (this.currShortCode) {
                case 'fen':
                    return '[fen' + this.getCommonAttributes() + ']' + jQuery('#wpc-input-fen').val() + '[/fen]';
                case 'pgn':
                    var r = '[pgn';
                    var checkbox = jQuery('#wpc-pgn-tactics');
                    if (checkbox.prop('checked')) {
                        r += ' tactics=1';
                    }
                    r += this.getCommonAttributes();
                    r += ']' + jQuery('#wpc-input-pgn').val() + '[/pgn]';
                    return r;
                case 'chess':
                    var ret = '[chess';

                    var gameId = jQuery('#wpc-chess-input-game').val().trim();
                    var dbId = jQuery('#wpc-chess-input-db').val().trim();
                    var tactics = jQuery('#wpc-chess-input-tactics').prop('checked');
                    if (gameId.length > 0) {
                        ret += ' game=' + gameId;
                    } else if (dbId.length > 0) {
                        ret += ' db=' + dbId;
                    }

                    if (tactics) {
                        ret += ' tactics=1';
                    }

                    ret += this.getCommonAttributes();

                    ret += ']';
                    return ret;
            }
        },


        getFenContent: function () {
            var c = jQuery('<div></div>');


            var input = '<input type="text" id="wpc-input-fen" placeholder="insert fen here" style="width:100%">';
            c.append(input);

            c.append(this.getTableForInputs(this.getCommonContent(), 'fen'));
            return c;
        },

        getPgnContent: function () {
            var h = this.contentContainer.height() - 30;
            var c = jQuery('<div></div>');
            c.css('height', h);
            var input = '<textarea id="wpc-input-pgn" placeholder="insert pgn of ONE game here" style="width:100%;height:100%">';
            c.append(input);

            var id = 'wpc-pgn-tactics';
            var tactics = '<input type="checkbox" id="' + id + '" value="1"> <label for="' + id + '">Tactics</label>';
            c.append(tactics);

            c.append(this.getTableForInputs(this.getCommonContent(), 'pgn'));

            return c;
        },

        getChessContent: function () {
            var c = jQuery('<div></div>');

            var inputs = [
                {
                    title: 'Game id', id: 'game', type: 'text', placeholder: 'Game id', label: 'Game:', suffix: 'or'
                }, {
                    title: 'Database id', id: 'db', type: 'text', placeholder: 'Database id', label: 'Database:'
                },
                {
                    title: 'Tactics', id: 'tactics', type: 'checkbox', label: 'Tactics'
                }
            ];

            inputs = inputs.concat(this.getCommonContent());

            c.append(this.getTableForInputs(inputs, 'chess'));

            return c;
        },


        getTableForInputs: function (inputs, title) {
            var table = jQuery('<table style="width:100%"></table>');

            var rows = this.getRows(inputs, title);

            jQuery.each(rows, function (i, row) {
                table.append(jQuery(row));
            });
            return table;
        },

        getRows: function (inputs, title) {
            var rows = [];
            jQuery.each(inputs, function (i, input) {

                var id = 'wpc-' + title + '-input-' + input.id;
                var row = "";
                switch (input.type) {

                    case 'text':
                        row = '<tr><td><label for="' + id + '">' + input.label + '</label></td>'
                            + '<td><input type="text" id="' + id + '" placeholder="' + input.placeholder + '"></td>';
                        break;
                    case 'checkbox':
                        row = '<tr><td colspan="2"><input type="checkbox" id="' + id + '" value="1"> <label for="' + id + '">' + input.label + '</label></td>';
                        break;
                    case 'select':
                        row = '<tr><td><label for="' + id + '">' + input.label + '</label></td><td><select id="' + id + '">';

                        jQuery.each(input.options, function (i, option) {
                            var isObj = jQuery.isPlainObject(option);

                            var val = isObj ? option.v : option;
                            var txt = isObj ? option.t : option;
                            row += '<option value="' + val + '">' + txt + '</option>';
                        });

                        row += '</select></td>';
                }

                if (row) {
                    row += '<td>' + (input.suffix ? input.suffix : '') + '</td></tr>';
                }

                if (row) rows.push(row);

            });

            return rows;

        },

        getCommonAttributes: function () {

            var attributes = [];
            jQuery.each(this.commonAttributes, function(i, attr){
               attributes.push(attr.id);
            });
            var sc = this.currShortCode;
            var ret = '';

            jQuery.each(attributes, function (i, attr) {
                var el = jQuery('#wpc-' + sc + '-input-' + attr);
                if (el.length) {
                    if (el.attr('type') === 'checkbox') {
                        if (el.prop('checked')) {
                            ret += ' ' + attr + '="1"';
                        }
                    } else {
                        var val = el.val().trim();
                        if (val.length) {
                            ret += ' ' + attr + '="' + val + '"';
                        }
                    }
                }

            });

            return ret;
        },

        commonAttributes: [

            {
                label: 'Template #',
                id:'tpl',
                type:'text',
                placeholder: 'Example: 1',
                suffix:'When not default'
            },
            {
                label: 'Theme',
                id: 'theme',
                type: 'select',
                options: [
                    {t: 'Default', v: ''},
                    {t: 'custom', v: 'Custom'},
                    {t: 'brown', v: 'Grey'},
                    {t: 'grey', v: 'Grey'},
                    {t: 'blue', v: 'Blue'},
                    {t: 'Light Grey', v: 'light-grey'},
                    {t: 'green', v: 'green'},
                    {t: 'Wood 1', v: 'wood1'},
                    {t: 'Wood 2', v: 'wood2'},
                    {t: 'Wood 3', v: 'wood3'},
                    {t: 'Wood 4', v: 'wood4'},
                    {t: 'Wood 5', v: 'wood5'},
                    {t: 'Wood 6', v: 'wood6'},
                    {t: 'Wood 7', v: 'wood7'},
                    {t: 'Wood 8', v: 'wood8'}
                ],
                suffix: ''
            },
            {
                label: 'Width',
                id: 'width',
                type: 'text',
                placeholder: 'Width on large devices',
                suffix: 'examples: 50%, 500px'
            },
            {
                label: 'Alignment',
                id: 'float',
                type: 'select',
                options: [{v: '', t: 'None'}, {v: 'left', t: 'Left'}, {v: 'right', t: 'Right'}],
                suffix: 'When width is specified'
            }
        ],

        getCommonContent: function () {

            return this.commonAttributes;
        },


        /**
         * Creates control instances based in the incomming name. This method is normally not
         * needed since the addButton method of the tinymce.Editor class is a more easy way of adding buttons
         * but you sometimes need to create more complex controls like listboxes, split buttons etc then this
         * method can be used to create those.
         *
         * @param {String} n Name of the control to create.
         * @param {tinymce.ControlManager} cm Control manager to use inorder to create new control.
         * @return {tinymce.ui.Control} New control instance or null if no control was created.
         */
        createControl: function (n, cm) {
            return null;
        },

        /**
         * Returns information about the plugin as a name/value array.
         * The current keys are longname, author, authorurl, infourl and version.
         *
         * @return {Object} Name/value array containing information about the plugin.
         */
        getInfo: function () {
            return {
                longname: 'WordPressChessFree',
                author: 'Alf Magne Kalleland',
                authorurl: 'http://dhtmlchess.com',
                infourl: 'https://wordpresschess.com',
                version: "1.0.83"
            };
        }
    });
    // Register plugin
    tinymce.PluginManager.add('wordpresschess_free', tinymce.plugins.wordpresschessfree);
})();