<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://www.dhtmlchess.com
 * @since      1.0.0
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/admin
 * @author     Alf Magne Kalleland <alf.magne.kalleland@gmail.com>
 */
class Wordpresschess_free_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $plugin_name The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string $plugin_name The name of this plugin.
     * @param      string $version The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Dhtml_chess_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Dhtml_chess_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wordpresschess-admin.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Dhtml_chess_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Dhtml_chess_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */


        if ('settings_page_dhtml_chess' == get_current_screen()->id) {
            wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wordpresschess-admin.js', array('jquery'), $this->version, false);
        }


    }

    /**
     *
     * admin/class-wp-cbf-admin.php - Don't add this
     *
     **/

    /**
     * Register the administration menu for this plugin into the WordPress Dashboard menu.
     *
     * @since    1.0.0
     */

    public function add_plugin_admin_menu()
    {

        /*
         * Add a settings page for this plugin to the Settings menu.
         *
         * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
         *
         *        Administration Menus: http://codex.wordpress.org/Administration_Menus
         *
         */
        add_options_page(
            'WordPressChess Settings', // Page title
            'WordPressChess Free',  // menu title
            'manage_options', // capabilities
            $this->plugin_name, // menu slug
            array($this, 'display_plugin_setup_page') // callback function
        );

        /**
         * add_menu_page( string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '', string $icon_url = '', int $position = null )
         *
         * add_submenu_page( string $parent_slug, string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '' )
         *
         */


	    add_menu_page('WordPressChess', 'WordPressChess', 'edit_posts', $this->plugin_name . "_top_menu", array($this, 'display_plugin_setup_page'), plugins_url($this->plugin_name . "/assets/menu-icon.png", $this->plugin_name));
	    add_submenu_page($this->plugin_name . "_top_menu", __('Shortcodes', $this->plugin_name), __('Shortcodes', $this->plugin_name), 'edit_posts', $this->plugin_name . "_tags", array($this, 'display_tags'));
	    add_submenu_page($this->plugin_name . "_top_menu", __('Game Editor', $this->plugin_name), __('Game Editor', $this->plugin_name), 'edit_posts', $this->plugin_name . "_editor", array($this, 'display_chess_editor'));
	    add_submenu_page($this->plugin_name . "_top_menu", __('Archived Databases', $this->plugin_name), __('Archived Databases', $this->plugin_name), 'edit_posts', $this->plugin_name . "_archived", array($this, 'display_archived_databases'));
	    add_submenu_page($this->plugin_name . "_top_menu", __('Import PGN', $this->plugin_name), __('Import PGN', $this->plugin_name), 'edit_posts', $this->plugin_name . "_import_pgn", array($this, 'display_import'));
	    add_submenu_page($this->plugin_name . "_top_menu", __('Support', $this->plugin_name), __('Support', $this->plugin_name), 'edit_posts', $this->plugin_name . "_support", array($this, 'display_support'));
	    add_submenu_page($this->plugin_name . "_top_menu", __('PRO version', $this->plugin_name), __('PRO version', $this->plugin_name), 'edit_posts', $this->plugin_name . "_pro", array($this, 'display_pro'));

        #remove_submenu_page('dhtml chess', 'dhtml chess');

    }

    /**
     * Add settings action link to the plugins page.
     *
     * @since    1.0.0
     */

    public function add_action_links($links)
    {
        /*
        *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
        */
        $settings_link = array(#'<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
        );
        return array_merge($settings_link, $links);

    }

    /**
     * Render the settings page for this plugin.
     *
     * @since    1.0.0
     */

    public function display_tags()
    {
        include_once('partials/dhtml_chess-admin-tags.php');
    }

    public function display_support()
    {
        include_once('partials/dhtml_chess-admin-support.php');
    }

    public function display_pro()
    {
        include_once('partials/wordpresschess-pro.php');
    }

    public function display_archived_databases()
    {
        include_once('partials/dhtml_chess-admin-archived.php');
    }

    public function display_plugin_setup_page()
    {
        include_once('partials/dhtml_chess-admin-display.php');
    }

    public function display_chess_editor()
    {
        include_once('partials/dhtml_chess-admin-editor.php');
    }

    public function display_import()
    {
        include_once('partials/dhtml_chess-admin-import-pgn.php');
    }

    public function options_update()
    {
        register_setting($this->plugin_name, $this->plugin_name, array($this, 'validate'));
    }


    public function importpgn_update()
    {
        register_setting($this->plugin_name, $this->plugin_name, array($this, 'validate'));

    }

    public function validateUpload($input)
    {
        var_dump($input);


        return array();
    }

    private function exists($input, $key)
    {
        return isset($input[$key]) && !empty($input[$key]);
    }

    public function validate($input)
    {
        // All checkboxes inputs

        $valid = array();

        $valid['theme'] = $this->exists($input, "theme") ? preg_replace("/[^0-9a-z_]/si", "", $input['theme']) : "wood1";
        $valid['pieces'] = $this->exists($input, "pieces") ? preg_replace("/[^0-9a-z_\-]/si", "", $input['pieces']) : "svg_bw";
        $valid['language'] = $this->exists($input, "language") ? preg_replace("/[^0-9a-z]/si", "", $input['language']) : "en";
        $valid['default_game_tpl'] = $this->exists($input, "default_game_tpl") ? preg_replace("/[^0-9]/si", "", $input['default_game_tpl']) : "1";
        $valid['default_db_tpl'] = $this->exists($input, "default_db_tpl") ? preg_replace("/[^0-9]/si", "", $input['default_db_tpl']) : "1";
        $valid['remove_on_uninstall'] = $this->exists($input, "remove_on_uninstall") ? $input['remove_on_uninstall'] : "0";
        $valid['arrow_styles'] = $this->exists($input, "arrow_styles") ? preg_replace('/[^0-9a-z;\-#\.\:]/si', '', $input['arrow_styles']) : '';

        return $valid;
    }


}
