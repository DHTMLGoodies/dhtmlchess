<?php

/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 31/01/2017
 * Time: 22:43
 */
class Wordpresschess_free_Upgrade
{

    public static function upgrade()
    {
        
        $installer = new DhtmlChessInstaller();
        $installer->upgrade();
    }
}