<?php
/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 31/01/2017
 * Time: 22:40
 */

class Wordpresschess_free_Uninstall{

    public static function uninstall() {

        $installer = new DhtmlChessInstaller();
        $installer->uninstall();
    }
}