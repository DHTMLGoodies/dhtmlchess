<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.dhtmlchess.com
 * @since      1.0.0
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/public
 * @author     Alf Magne Kalleland <alf.magne.kalleland@gmail.com>
 */
class Wordpresschess_free_Public
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $this ->plugin_name The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    private $dhtml_chess_options;

    private $config_added = false;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     *
     * @param      string $this ->plugin_name The name of the plugin.
     * @param      string $version The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

        $this->dhtml_chess_options = get_option($this->plugin_name);

    }

    function addShortCodes()
    {

        wp_enqueue_script("jquery");
        add_shortcode("fen", array($this, "shortcode_handler"));
        add_shortcode("pgn", array($this, "shortcode_handler"));
        # add_shortcode( "chess", array( $this, "shortcode_handler" ) );
        add_shortcode("pgnignore", array($this, "shortcode_handler"));
        add_shortcode("fenignore", array($this, "shortcode_handler"));
        add_shortcode("chessignore", array($this, "shortcode_handler"));
    }


    private function getLanguage()
    {
        return DhtmlChessViews::getTranslatedJSStrings($this->plugin_name);
    }

    private static $customCssRendered = false;

    private function getCustomCssJs()
    {
        if (!self::$customCssRendered) {
            self::$customCssRendered = true;
            $css = get_option(WORDPRESSCHESS_OPTION_CUSTOM_THEME_CSSSTRING, "");
            $css = str_replace('\"', '', $css);
            $ret = '<style type="text/css">' . $css . '</style>';
            $js = get_option(WORDPRESSCHESS_OPTION_CUSTOM_THEME);
            $ret .= '<script type="text/javascript"> wpchess_add_snippet(function(){ chess.CUSTOMTHEME = ' . stripslashes($js) . ' });</script>';
            return $ret;
        } else {
            return "";
        }
    }

    private static $scriptQueueAdded = false;

    private function getScriptQueue(){
        if(!self::$scriptQueueAdded){
            self::$scriptQueueAdded = true;

            return '<script type="text/javascript">
            var wpchess_snippets = [];
            function wpchess_add_snippet(fn){
                wpchess_snippets.push(fn);     
            }
            </script>';
        }
        return "";
    }



    function shortcode_handler($attributes, $content = null, $tag)
    {

        try {


            if (strstr($tag, "ignore") || (!empty($attributes) && isset($attributes["ignore"]))) {

                $tag = str_replace("ignore", "", $tag);
                $ret = '[' . $tag;

                foreach ($attributes as $key => $val) {
                    if ($key != "ignore") {
                        $ret .= ' ' . $key . '="' . $val . '"';
                    }
                }

                $ret .= ']';

                if (!empty($content)) {
                    $ret .= $content . '[/' . $tag . ']';
                }

                return $ret;
            }

            if (($tag == "fen" || $tag == "pgn") && empty($content)) {
                return '[' . $tag . ' "' . implode(",", $attributes) . '"]';
            }

            $options = get_option($this->plugin_name);
            $default_game_tpl = isset($options["default_game_tpl"]) ? $options["default_game_tpl"] : 1;
            $default_db_tpl = isset($options["default_db_tpl"]) ? $options["default_db_tpl"] : 1;
            $arrow_styles = isset($options["arrow_styles"]) ? $options["arrow_styles"] : "";
            $arrow_styles_actions = isset($options["arrow_styles_actions"]) ? $options["arrow_styles_actions"] : "";

            $theme = !empty($options['theme']) ? $options['theme'] : "grey";

            wp_localize_script('ajax-script', 'ajax_object', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'we_value' => 1234
            ));

            wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . '../api/css/dhtml-chess-wordpress-free-minified.css', array(), $this->version, 'all');
            wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . '../api/js/dhtml-chess-wordpress-free.js', array("jquery"), $this->version, false);
            wp_enqueue_style($this->plugin_name . 'override', plugin_dir_url(__FILE__) . '../api/themes/overrides.css', array(), $this->version, 'all');
            wp_enqueue_style($this->plugin_name . 'themecss', plugin_dir_url(__FILE__) . '../api/themes/' . $theme . '.css', array(), $this->version, 'all');
            wp_enqueue_script($this->plugin_name . "theme", plugin_dir_url(__FILE__) . '../api/themes/' . $theme . '.js', array(), $this->version, false);


            if (empty($attributes)) {
                $attributes = array();
            }

            $attributes["defaultTheme"] = $theme;

            if (!empty($attributes["standings"])) {
                $attributes["leaderboard"] = 1;
            }
            if ($tag == "chess" && !empty($attributes["leaderboard"]) && !empty($attributes["tpl"]) && $attributes["tpl"] == 2 && !empty($attributes["db"])) {
                $handler = new DhtmlChessViews();
                $sofiaRules = !empty($attributes["sofiaRules"]) ? $attributes["sofiaRules"] : false;

                return $handler->standingsAsHTML($attributes["db"], $sofiaRules);
            }

            $prefix = $this->getScriptQueue();
            $prefix .= $this->getCustomCssJs();


            if (!$this->config_added) {
                $this->config_added = true;
                $pieces = !empty($options['pieces']) ? $options['pieces'] : "svg_bw";

                $prefix .= $this->getLanguage() . '<script type="text/javascript">
            // Chess For Wordpress www.dhtmlchess.com
            wpchess_add_snippet(function(){
                    if(chess.THEME)chess.THEME["chess.view.board.Board"].pieceLayout="' . $pieces . '";
                    chess.OVERRIDES = {
                        arrow_styles : "' . $arrow_styles . '",
                        arrow_styles_actions: "' . $arrow_styles_actions . '"
                    };
                    ludo.config.wpRoot = "' . network_site_url() . '";
                    ludo.config.setUrl("' . admin_url('admin-ajax.php') . '");
                    ludo.config.setDocumentRoot("' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . '/");
            });
            </script>';
            };

            $docRoot = plugins_url($this->plugin_name . "/api/", $this->plugin_name);
            $handler = new DhtmlChessViews();


            if (empty($attributes["tpl"])) {
                if ($tag == 'fen') {
                    $attributes["tpl"] = 6;
                } else if (isset($attr["game"]) || $tag == "pgn") {
                    $attributes["tpl"] = $default_game_tpl;
                } elseif (isset($attr["db"]) && !isset($attr["tactics"])) {
                    $attributes["tpl"] = $default_db_tpl;
                } else {
                    $attributes["tpl"] = 1;

                }
            }

            if ($tag == "fen") {
                $view = $handler->getParsedTagFromAttributes("fen", $attributes, $content);

                return $prefix . $view->getJS($docRoot);
            } else if ($tag == "pgn") {
                $view = $handler->getParsedTagFromAttributes("pgn", $attributes, $content);

                return $prefix . $view->getJS($docRoot);
            } else {
                $view = $handler->getParsedTagFromAttributes("chess", $attributes, $content);

                return $prefix . $view->getJS($docRoot);
            }

        } catch (Exception $e) {
            $this->config_added = false;

            return "";
        }
    }


    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Dhtml_chess_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Dhtml_chess_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */


    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Dhtml_chess_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Dhtml_chess_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

    }

}
