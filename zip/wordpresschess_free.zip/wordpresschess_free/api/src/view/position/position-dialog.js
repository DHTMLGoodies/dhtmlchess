/**
 * Created by alfmagne1 on 10/05/2017.
 */
chess.wordpress.PositionDialog = new Class({

    Extends: chess.view.position.Dialog,
    autoRemove: false,
    title: 'Chess Position Builder',
    layout: {
        width: 800,
        height: 550
    },
    closable: true,
    fen: undefined,
    resizable:true,


    __constructor: function (config) {
        config = config ||{};

        config.buttonBar = {
            align: 'left',
            children: [
                {
                    value: 'OK',
                    listeners: {
                        click: this.sendPosition.bind(this)
                    }
                },
                {
                    weight: 1
                },
                {
                    value: 'Reset',
                    listeners: {
                        click: this.resetBoard.bind(this)
                    }
                },
                {
                    value: 'Clear board',
                    listeners: {
                        click: this.clearBoard.bind(this)
                    }
                },
                {
                    value: 'Load fen',
                    listeners: {
                        click: this.showLoadFenDialog.bind(this)
                    }
                },
                {
                    value: 'Flip',
                    listeners: {
                        click: this.flipBoard.bind(this)
                    }
                },
                {
                    value: 'Cancel',
                    listeners: {
                        click: this.hide.bind(this)
                    }
                }
            ]
        };
        this.parent(config);

    },

    showPositionDialog: function (parentDialog, fen) {
        this.fen = fen || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
        var off = parentDialog.offset();

        this.showAt(off.left - 20, off.top + 20);
    },

    __rendered: function () {
        this.parent();
        this.$b().addClass('dc-grey');
    }
});