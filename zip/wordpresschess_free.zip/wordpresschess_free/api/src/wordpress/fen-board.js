chess.wordpress.FenBoard = new Class({
    Extends: chess.view.position.Board,
    mode: 'insertPiece',

    curColor: undefined,

    addBoardEvents: function () {

        this.els.board.on('click', this.onBoardClick.bind(this));
        this.addEvent('resetboard', this.sendFen.bind(this));
        this.addEvent('modifyboard', this.sendFen.bind(this));
        this.addEvent('clearboard', this.sendFen.bind(this));
        this.addEvent('render', this.sendFen.bind(this));
    },


    onBoardClick: function (e) {
        var square = this.getSquareByEvent(e);
        if (square === undefined)return;

        var squareString = Board0x88Config.numberToSquareMapping[square];
        switch (this.mode) {
            case 'insertPiece':
                this.insertPiece(e);
                break;
            case 'arrow':


                break;
            case 'highlight':
                this.highlightPool().show(squareString, this.curColor);
                break;

        }
        if (this.mode === 'insertPiece') {
            this.insertPiece(e);
        }
    },

    startHighlight: function (color) {
        console.log(color);
        this.mode = 'highlight';
        this.curColor = color;
    },

    startArrowMode: function (color) {
        this.mode = 'arrow';
        this.curColor = color;
    },

    setMode: function (mode) {
        this.mode = mode;
    },

    clearMode: function () {
        this.mode = 'insertPiece';
    },

    highlightPool: function () {
        if (this._highlightPool === undefined) {
            this._highlightPool = new chess.view.highlight.SquarePool({
                board: this,
                autoToggle:true
            });
        }

        return this._highlightPool;

    },

    _arrowPool: undefined,
    arrowPool: function () {
        if (this._arrowPool === undefined) {
            this._arrowPool = new chess.view.highlight.ArrowPool({
                board: this
            });
        }
        return this._arrowPool;

    }
});