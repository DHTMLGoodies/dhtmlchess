chess.wordpress.PublishConfirmDialog = new Class({
    Extends: ludo.dialog.Confirm,
    autoremove:false,
    css: {
        padding: 5
    }
    
})