<?php

/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 17/04/2017
 * Time: 14:22
 */
class DhtmlChessThemeBuilder
{

    private static $tpl = '{
    "name": "custom",
    "borderColor":"#aaa",
    "css": {

        
    },
    "chess.view.board.Board": {
        "pieceLayout":"svg_bw",
        "labelStyles":{
            "color": "#FFF"
        },
        "background":{
            "borderRadius":"1%",
            "horizontal":"images/board-bg/wood-strip-horizontal.png",
            "vertical":"images/board-bg/wood-strip-vertical.png",
            "iePaint":{
                "fill": "#6b2d1a"
            }
        },
        "bgWhite": "images/board/lighter-wood.png",
        "bgBlack": "images/board/darker-wood.png",
        "plugins": [
            {
                "type": "chess.view.highlight.Arrow",
                "styles":{
                    "fill": "#039BE5",
                    "stroke":"#0D47A1"
                }
            },
            {
                "type": "chess.view.highlight.ArrowTactic",
                "styles":{
                    "fill": "#039BE5",
                    "stroke":"#0D47A1"
                }
            },
            {
                "type": "chess.view.highlight.SquareTacticHint"
            }
        ]
    },
    "chess.view.dialog.PuzzleSolved": {
    },
    "chess.view.notation.TacticPanel": {
        "css": {
            "text-align": "center",
            "color": "#444"
        }
    },
    "chess.view.notation.Panel": {
        "figurines":"svg_egg"
    },
    "chess.view.notation.Table": {
        "figurines":"svg_egg"
    },
    "chess.view.notation.LastMove": {
        "figurines":"svg_egg"
    },
    "chess.view.buttonbar.Bar":{
        "borderRadius":"10%",
        "styles":{
            "button":{
                "fill":"#6e3f31",
                "stroke":"#6e3f31"
            },
            "image":{
                "fill":"#e8bfa0"
            },
            "buttonOver":{
                "fill":"#6e483c",
                "stroke":"#6e3f31"
            },
            "imageOver":{
                "fill":"#e8bfa0"
            },
            "buttonDown":{
                "fill":"#8c6445",
                "stroke":"#6e3f31"
            },
            "imageDown":{
                "fill":"#e8bfa0"
            },
            "buttonDisabled":{
                "fill":"#d5c8c5",
                "stroke" : "#b38578",
                "stroke-opacity" : 0.3
            },
            "imageDisabled":{
                "fill":"#6e483c",
                "fill-opacity" : 0.3
            }
        }
    }


}';


    /**
     * @var array
     */
    private $json;

    private $theme;

    private $colorScriptAdded = false;

    public function __construct()
    {
        $this->theme = new DhtmlChessTheme();
        $this->json = json_decode(self::$tpl, true);
    }


    public function set($path, $val)
    {
        $item = &$this->arrayPath($path);
        $key = $this->getKey($path);
        if (isset($item) && isset($item[$key])) {
            echo "setting $key to $val";
            $item[$key] = $val;
        }
    }

    private function getKey($path)
    {
        $tokens = explode("/", $path);
        return array_pop($tokens);
    }

    private function &arrayPath($path)
    {

        $tokens = explode("/", $path);
        array_pop($tokens);

        $path = &$this->json;

        foreach ($tokens as $item) {
            if (!isset($path[$item])) {
                return null;
            }
            $path = &$path[$item];
        }

        return $path;
    }

    public function get($path)
    {
        $tokens = explode("/", $path);
        $key = array_pop($tokens);
        $path = $this->arrayPath($path);
        return isset($path[$key]) ? $path[$key] : null;
    }

    public function json()
    {
        return $this->json;
    }


    public function categoryHtml($category)
    {
        $fields = $this->theme->categoryFields($category);

        foreach ($fields as &$field) {
            $val = $this->get($field["name"]);
            $field["val"] = !empty($val) ? $val : "";
        }

        $html = "<table>";

        foreach($fields as $field){
            $html .= $this->fieldHtml($field);
        }

        $html .= "</table>";
        return $html;


    }

    public function fieldHtml($field)
    {
        $html = "<tr><td>". $field["label"] . "</td><td>";
        switch ($field["t"]) {

            case "n":
                $html .= $this->numericHtml($field);
                break;
            case "clr":
                $html .= $this->colorHtml($field);
                break;
            default:
                return "";

        }
        $html .= "</td></tr>";

        return $html;
    }

    private function colorHtml($field)
    {
        $n = $field["name"];
        $html = '<input class="wpc-color-picker" type="text" value="' . $field["val"] . '" id="\' id="' . $n . '" name="' . $n . '">';

        if (!$this->colorScriptAdded) {
            $html .= "<script type='text/javascript'>jQuery(document).ready(function($){
            $('.wpc-color-picker').wpColorPicker();
        });</script>";
        }

        return $html;

    }

    private function numericHtml($field)
    {
        return '<input type="text" value="' . $field["val"] . '" id="' . $field["name"] . '" name="' . $field["name"] . '">';

    }


}