<?php

class DhtmlChessException extends Exception
{

}

class DhtmlChessPgnNotFoundException extends DhtmlChessException{}
