<?php

/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 17/04/2017
 * Time: 12:48
 */
class DhtmlChessTheme
{



    /**
     * @var array
     */
    private $fields;


    private static $bgPath = "images/board-bg/";
    private static $piecePath = "images/";
    private static $squareBg = "images/board/";
    private static $imgNone = "images/none.png";

    public function __construct()
    {
    }



    public function categoryFields($category){
        $fields = $this->getFields();
        $ret = array();
        foreach($fields as $field){
            if($field["c"] == $category){
                $ret[] = $field;
            }
        }
        return $ret;
    }

    public function fieldByIndex($index)
    {
        $fields = $this->getFields();
        return $fields[$index];
    }

    public function getFields()
    {
        if (empty($this->fields)) {
            $fields = $this->borderFields();
            $fields = array_merge($fields, $this->boardFields());
            $this->fields = $fields;
            $this->setNames();
        }
        return $this->fields;
    }

    private function setNames()
    {

        foreach ($this->fields as &$field) {
            $field["name"] = $field["p"] . "/" . $field["f"];
        }
    }

    private function borderFields()
    {

        $fields = array(
            array(
                "p" => $this->bp() . "/background",
                "f" => "borderRadius",
                "t" => "n",
                "v" => '/^[0-9]{1,2}$/',
                "size" => 3,
                "maxlen" => 2,
                "def" => 1,
                "defm" => 0,
                "suffix" => "%",
                "label" => __('Border radius', "wordpresschess")
            )

        );

        return $this->applyCat($fields, "border");
    }

    public function fieldByName($name)
    {
        $fields = $this->getFields();
        foreach ($fields as $field) {
            if ($field["name"] == $name) return $field;
        }
        return null;
    }

    private function boardFields()
    {
        $fields = array(
            array(
                "p" => $this->bp(),
                "f" => "bgWhite",
                "t" => "img",
                "v" => null,
                "opt" => array(
                    self::$imgNone,
                    self::$squareBg . "lightest-wood.png",
                    self::$squareBg . "lighter-wood.png",
                    self::$squareBg . "light-wood.png",
                    self::$squareBg . "light-wood2.png",
                    self::$squareBg . "light-grey-wood.png",
                    self::$squareBg . "light-blue-wood.png",
                    self::$squareBg . "wood6.png",
                    self::$squareBg . "wood7.png",
                    self::$squareBg . "wood8.png",
                    self::$squareBg . "wood-1.png",
                    self::$squareBg . "wood-2.png",
                    self::$squareBg . "wood-bamboo.png",
                ),
                "size" => 3,
                "maxlen" => 2,
                "def" => 0,
                "defm" => 0,
                "suffix" => "%",
                "label" => __('White Squares', "wordpresschess")
            ),
            array(
                "p" => $this->bp(),
                "f" => "bgBlack",
                "t" => "img",
                "v" => null,
                "opt" => array(
                    self::$imgNone,
                    self::$squareBg . "dark-wood.png",
                    self::$squareBg . "dark-wood2.png",
                    self::$squareBg . "darker-wood.png",
                    self::$squareBg . "darker-wood2.png",
                    self::$squareBg . "darkest-wood.png",
                    self::$squareBg . "grey-wood.png",
                    self::$squareBg . "wood4.png",
                    self::$squareBg . "wood6.png",
                    self::$squareBg . "wood8.png",
                    self::$squareBg . "wood-cherry.png",
                ),
                "size" => 3,
                "maxlen" => 2,
                "def" => 0,
                "defm" => 0,
                "suffix" => "%",
                "label" => __('White Squares', "wordpresschess")
            ),
            array(
                "p" => $this->bp() . "/plugins/0/styles",
                "f" => "fill",
                "t" => "clr",
                "v" => '/^#[0-9A-Z]{6}$/',
                "size" => 3,
                "maxlen" => 2,
                "def" => 1,
                "suffix" => "%",
                "label" => __('Arrow fill color', "wordpresschess")
            ),
            array(
                "p" => $this->bp() . "/plugins/0/styles",
                "f" => "fill-opacity",
                "t" => "t",
                "v" => '/^#[0-9]?\.[0-9]$/',
                "size" => 3,
                "maxlen" => 2,
                "def" => .5,
                "suffix" => "",
                "label" => __('Arrow fill opacity(0-1)', "wordpresschess")
            ),
            array(
                "p" => $this->bp() . "/plugins/0/styles",
                "f" => "stroke",
                "t" => "clr",
                "v" => '/^#[0-9A-Z]{6}$/',
                "size" => 3,
                "maxlen" => 2,
                "def" => 1,
                "suffix" => "",
                "label" => __('Arrow stroke color', "wordpresschess")
            ),
            array(
                "p" => $this->bp() . "/plugins/0/styles",
                "f" => "stroke-opacity",
                "t" => "t",
                "v" => '/^#[0-9]?\.[0-9]$/',
                "size" => 3,
                "maxlen" => 2,
                "def" => .8,
                "suffix" => "",
                "label" => __('Arrow stroke opacity(0-1)', "wordpresschess")
            )
        );

        return $this->applyCat($fields, "board");
    }

    private function applyCat($array, $cat)
    {
        foreach ($array as &$entry) {
            $entry["c"] = $cat;
        }
        return $array;
    }


    private function bp()
    {
        return "chess.view.board.Board";
    }



}

