<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alf Magne Kalleland
 * Date: 15.01.13

 */
class People extends LudoDBCollection
{
    protected $JSONConfig = true;
}
