<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alf Magne Kalleland
 * Date: 12.01.13

 */
class Section extends LudoDBModel
{
    protected $JSONConfig = true;
}
