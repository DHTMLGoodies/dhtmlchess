<?php
/**
 * Comment pending.
 * User: Alf Magne Kalleland
 * Date: 13.04.13
 * Time: 19:03
 */
class TLudoJSCountry extends LudoDBModel
{
    protected $JSONConfig = true;
}
