<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alf Magne Kalleland
 * Date: 16.01.13

 */
class PeoplePlain extends LudoDBCollection
{
    protected $JSONConfig = true;
}
