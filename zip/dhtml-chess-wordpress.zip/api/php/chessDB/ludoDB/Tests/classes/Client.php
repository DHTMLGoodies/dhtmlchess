<?php
class Client extends LudoDBModel
{
    protected $JSONConfig = true;

}
