<?php
/**
 *
 * User: Alf Magne
 * Date: 06.02.13

 */
class AnotherChild extends AChild
{

}
