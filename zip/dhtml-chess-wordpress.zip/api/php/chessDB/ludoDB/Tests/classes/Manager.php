<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alf Magne
 * Date: 10.01.13


 */
class Manager extends Client
{
    protected $JSONConfig = true;
}
