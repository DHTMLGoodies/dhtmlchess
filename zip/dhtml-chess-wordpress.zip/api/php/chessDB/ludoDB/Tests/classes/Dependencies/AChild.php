<?php
/**
 *
 * User: Alf Magne
 * Date: 06.02.13

 */
class AChild extends LudoDBModel
{
    protected $JSONConfig = true;
}
