<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alf Magne Kalleland
 * Date: 06.02.13
 */
class Country extends LudoDBModel
{
    protected $JSONConfig = true;
}
