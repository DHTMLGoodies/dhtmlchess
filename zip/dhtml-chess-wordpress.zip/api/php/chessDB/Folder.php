<?php
/**
 * LudoDB Model for chess folders
 * User: Alf Magne
 * Date: 18.01.13
 */
class Folder extends LudoDBModel
{
    protected $JSONConfig = true;

    protected function clearCache(){
        LudoDBCache::clearByClass("Folders");
    }
}
