<?php
/**
 *
 * User: Alf Magne
 * Date: 27.02.13
 * Time: 13:40
 */
class GameCategory extends LudoDBModel
{
    const CORRESPONDENCE = 1;
    const BLITZ = 2;
    const TACTICS = 3;
    const STANDARD = 4;
}
