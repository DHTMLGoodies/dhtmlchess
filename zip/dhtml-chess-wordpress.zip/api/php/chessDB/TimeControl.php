<?php
/**
 * Time control class
 */
class TimeControl extends LudoDBModel
{
    protected $JSONConfig = true;
}
