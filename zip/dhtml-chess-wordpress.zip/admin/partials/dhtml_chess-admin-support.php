<style type="text/css">
    li{
        margin-left:20px;
        list-style-type: disc;

    }
</style>
<h1>DHTML Chess Support</h1>

<h2>How to Use</h2>
<p>Insert short tags into your posts using the format below. You can preview the tags from the <strong>Shorttags</strong> menu item.</p>
<p>This are the available tags:</p>
<ul>

<li><strong>[chess &lt;properties>]</strong></li>
<li><strong>[fen &lt;properties>]&lt;fen string>[/fen]</strong></li>
<li><strong>[pgn &lt;properties>]&lt;pgn string>[/fen]</strong></li>
</ul>
<h3>Samples</h3>
<p>[chess db="1" tpl="1"] : Show games from pgn database 1 using view template 1 <br>
[chess game="100" tpl="5"] : Show game with id 100, using game template 5 <br>
[chess game="100" tpl="5" theme="brown"] : Same as above, but override default template. <br>
[fen]k1K5/p7/P1N5/1P6/4pP2/2p1P3/pp6/r3Q3 w - - 0 1[/fen] : Show board with this <a href="https://en.wikipedia.org/wiki/Forsyth%E2%80%93Edwards_Notation" onclick="var w = window.open(this.href);return false">fen position</a><br>


</p>
<h3>Properties</h3>
<p>These are the available properties:</p>
<ul>
    <li><strong>db="&lt;id>"</strong>: Which database to show games from. Database id's are highlighted in the game editor. When rendering games from a database, DHTML Chess
    will use a template where you can choose which games to show on the board from a list.</li>
    <li><strong>game="&lt;id>"</strong>: Id of game to show. Game id's are also highlighted in the game editor.</li>
    <li><strong>tpl="&lt;template number>"</strong>: Which template to choose when rendering the board. There are different templates to choose from for game and
        database views. Example: to show a game using the fifth game template, set tpl to "5". The different templates can be previews from the shorttags
    menu item.</li>
    <li><strong>theme="&lt;theme name>"</strong>: Optional property which lets you override default theme.</li>
</ul>

<h2>Import PGN</h2>
<p>PGN files can be imported from the <strong>Import PGN</strong> menu item. The PGN will be saved on the server as a game database which you can
render games from using the [chess] shorttag.</p>
<h2>Archive Database</h2>
<p>If you have a lot of databases, you can hide the ones you don't use often by archiving them.</p>
<p>You archive a database using swipe right gestures from the list of databases in the game editor.</p>
<p>An Archived database is still available, but it won't show up in the game editor. An archived database
    can later be made available from the <strong>Archived databases</strong> admin page.</p>

<h2>Delete a Database</h2>
<p>If you want to permanently delete a database, you will first have to archive it, then delete it from
the list of archived databases by swiping left on the database in the list.</p>

<h2>The Game Editor</h2>
<p>The Game Editor let's you edit games online and make them available on your web page.</p>
<p>Here are some of the key features of the editor:</p>
<ul>
    <li>Support for saving drafts. A draft is not available from the web page. You can work on a draft
    as long as you want, and once it's ready, you can publish it in a database.</li>
    <li>Support for StockfishJS. Stockfish JS is a Javascript version of Stockfish. It is a fairly
    strong engine, but not as efficent as other native Chess Engines since it's running in the browser.
    From the Engine Analysis, you can append the engine analysis as variations to your games and also
    append computer eval as a comment. </li>
    <li>Online Annotations - The Game Editor has a feature for annotating the games.</li>
</ul>

<h2>DHTML Chess Forums</h2>
<p>For more help, visit <a href="http://www.dhtmlchess.com/forums" onclick="var w=window.open(this.href);return false">dhtmlchess.com/forums</a></p>