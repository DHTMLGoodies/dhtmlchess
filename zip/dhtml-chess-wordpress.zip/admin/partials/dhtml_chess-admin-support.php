<h1>DHTML Chess Support</h1>

<h2>How to Use</h2>
<p>You display chess boards on your website by inserting special tags in your posts. You can quickly get an overview
of tags from the <strong>Chess Tags for Posts</strong> menu item.</p>
<p>This is the TAG format:</p>
<p><strong>[DC;&lt;template>;&lt;game/database id>;&lt;optional properties>]</strong></p>
<p>Here are a couple of examples::</p>
<ul>
    <li>strong>[DC;D1;2]</strong>: Show board with list of games from database id 2. Use the first Database View template(D1)</li>
    <li>strong>[DC;G2;100]</strong>: Show the game with id 100 using Game View Template 2(G2)</li>
</ul>
<p>The tags</p>
<ol>
    <li>Starts and ends with a square bracket. []</li>
    <li>Has different parts separated by semicolon.</li>
    <li>Has <strong>DC</strong> ("Dhtml Chess") as it's first part</li>
    <li>Has reference to template as second part.
        <ul>
            <li><strong>D</strong> for Database views</li>
            <li><strong>G</strong> for Single Game view</strong></li>
            <li><strong>T</strong> for Tactics Training</strong></li>
        </ul>
        Followed by a number. There are multiple Chess Views to choose from. D1 is the first Template for
        showing games in a database.
    </li>
    <li>Has a numeric reference to a <strong>Database</strong> or <strong>Game</strong> as it's third attribute.
    You can find these id's quickly from the Game Editor. In the examples above, you will se a reference to database
    with id 2 and a game with id 100.</li>
    <li>Has support for additional optional parameters defined in key/value pairs separated by a semicolon. <br>
        Example:<br>
        <strong>[DC;D1;2;theme=brown;width:300]</strong><br>
        Which overrides default theme and sets the board width to 300px.
    </li>
</ol>

<h2>Archive Database</h2>
<p>If you have a lot of databases, you can hide the ones you don't use often by archiving them.</p>
<p>You archive a database using swipe right gestures from the list of databases in the game editor.</p>
<p>An Archived database is still available, but it won't show up in the game editor. An archived database
    can later be made available from the <strong>Archived databases</strong> admin page.</p>

<h2>Delete a Database</h2>
<p>If you want to permanently delete a database, you will first have to archive it, then delete it from
the list of archived databases by swiping left on the database in the list.</p>

<h2>The Game Editor</h2>
<p>The Game Editor let's you edit games online and make them available on your web page.</p>
<p>Here are some of the key features of the editor:</p>
<ul>
    <li>Support for saving drafts. A draft is not available from the web page. You can work on a draft
    as long as you want, and once it's ready, you can publish it in a database.</li>
    <li>Support for StockfishJS. Stockfish JS is a Javascript version of Stockfish. It is a fairly
    strong engine, but not as efficent as other native Chess Engines since it's running in the browser.
    From the Engine Analysis, you can append the engine analysis as variations to your games and also
    append computer eval as a comment. </li>
    <li>Online Annotations - The Game Editor has a feature for annotating the games.</li>
</ul>