<?php
wp_enqueue_style($this->plugin_name . "css", plugin_dir_url(__FILE__) . '../../api/css/dhtml-chess-all.css', array(), $this->version, 'all');
wp_enqueue_script($this->plugin_name . "js", plugin_dir_url(__FILE__) . '../../api/js/dhtml-chess-minified.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "not-tbl", plugin_dir_url(__FILE__) . '../../api/src/view/notation/table.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "not-lm", plugin_dir_url(__FILE__) . '../../api/src/view/notation/last-move.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "stockfish", plugin_dir_url(__FILE__) . '../../api/src/controller/stockfish-engine-controller.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "editor", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-editor-minified.js', array("jquery"), $this->version, false);
#wp_enqueue_script($this->plugin_name . "wp-templates", plugin_dir_url(__FILE__) . '../../api/wordpress/wordpress-templates-minified.js?rnd=44', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates1", plugin_dir_url(__FILE__) . '../../api/wordpress/game-grid.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates2", plugin_dir_url(__FILE__) . '../../api/wordpress/wp-template.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates3", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game-template.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates4", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game1.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates5", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game2.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates6", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game3.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates7", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game4.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates10", plugin_dir_url(__FILE__) . '../../api/wordpress/game/game5.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates8", plugin_dir_url(__FILE__) . '../../api/wordpress/pgn/viewer1.js', array(), $this->version, false);
wp_enqueue_script($this->plugin_name . "wp-templates9", plugin_dir_url(__FILE__) . '../../api/wordpress/tactics/tactics1.js', array(), $this->version, false);
wp_enqueue_style($this->plugin_name . "css-overrides", plugin_dir_url(__FILE__) . '../../api/themes/overrides.css', array(), $this->version, 'all');

$options = get_option($this->plugin_name);
$theme = isset($options["theme"]) ? $options["theme"] : "wood1";

require_once(plugin_dir_path(__FILE__) . '../../api/autoload.php');

?>

<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <script type="text/javascript">

        var docRoot = '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>';

        var currentThemeCss;
        var currentThemeJs;
        var currentThemeName;

        function loadTheme(theme) {
            currentThemeName = theme;
            if (currentThemeCss != undefined) {
                currentThemeCss.remove();
            }
            currentThemeCss = jQuery('<link/>', {
                rel: 'stylesheet',
                type: 'text/css',
                href: docRoot + '/themes/' + theme + '.css?rnd=' + Math.random()
            });
            currentThemeCss.appendTo('head');

            jQuery.ajax({
                url: docRoot + '/themes/' + theme + '.js',
                dataType: "script",
                success: function () {

                    if (currentTag) {
                        loadPreview(currentTag);

                    }
                }
            });

        }

        jQuery(document).ready(function () {
            loadTheme('<?php echo $theme; ?>');
        });


        //
    </script>

    <?php


    $themes = array(
        array('brown', 'Brown'),
        array('grey', 'Grey'),
        array('blue', 'Blue'),
        array('wood1', 'Wood 1'),
        array('wood2', 'Red Wood'),
        array('wood3', 'Wood 3'),
        array('wood4', 'Light Brown Wood'),
        array('wood5', 'Wood 5'),
        array('wood6', 'Grey Wood'),
        array('wood7', 'Wood 7'),

    );


    $tags = DhtmlChessViews::getAvailableTags();

    ?>
    <script type="text/javascript">
        var tags = <?php echo json_encode($tags); ?>;
    </script>
    <h4><?php echo esc_html("Select from the list below to see preview of the templates and the tags you can use in your posts."); ?></h4>

    <fieldset class="dhtml-chess-admin-fieldset">
        <legend>Tags</legend>


        <select id="dhtml-chess-tag">
            <?php
            foreach ($tags as $index => $tag) {
                echo '<option value="' . $index . '">' . $tag["title"] . '</option>';
            }
            ?>
        </select><br>
        <script type="text/javascript">
            var defaultTheme = '<?php echo $theme; ?>';
        </script>

        <select id="dhtml-chess-theme">
            <option value="">Use default theme</option>
            <?php
            foreach ($themes as $th) {
                $key = $th[0];
                $val = $th[1];
                echo '<option value="' . $key . '">' . $val . '</option>';
            }

            ?>


        </select>
    </fieldset>
    <br>


    <script type="text/javascript">
        jQuery('#dhtml-chess-theme').on('change', function () {
            var val = jQuery('#dhtml-chess-theme option:selected').val();
            if (val.length > 0) {
                loadTheme(val);
            } else {
                loadTheme('<?php echo $theme; ?>')
            }

        });

        jQuery('#dhtml-chess-tag').on('change', function () {
            var val = jQuery('#dhtml-chess-tag option:selected').val();
            var tag = tags[val];
            loadPreview(tag);


        });

        var currentTag;

        function loadPreview(tag) {

            currentTag = tag;

            jQuery("#preview").empty();

            if (tag.type) {

                jQuery('#heading').html(tag.title);
                jQuery('#desc').html(tag.desc);
                jQuery('#help').show();
                var options;
                ludo.config.setUrl(window.ajaxurl);

                if (tag.type == 'g') {
                    options = getDefaultGameOptions();
                }
                if (tag.type == 'p') {
                    options = getDefaultPgnOptions();
                }
                if (tag.type == 't') {
                    options = getDefaultTacticOptions();
                }
                new chess[tag.script](options);

                updateTag();
            }

        }

        function updateTag() {
            jQuery('#tag-container').show();
            var html = '[DC;' + currentTag.tag;


            if (currentTag.type == 'g') {
                html += ';&lt;game id>';

            } else {

                html += ';&lt;database id>';
            }

            if (currentThemeName != defaultTheme) {
                html += ';theme:' + currentThemeName;
            }

            html += ']';


            jQuery('#tag').html(html);
        }

        function getDefaultTacticOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 2,
                    name: 'Tactics'
                }
            }
        }

        function getDefaultGameOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                gameId: 2
            }
        }

        function getDefaultPgnOptions() {
            return {
                docRoot: '<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>',
                renderTo: '#preview',
                pgn: {
                    id: 1,
                    name: 'Great Games'
                }
            }

        }

    </script>

    <h3 id="heading" style="display:none"></h3>
    <h4 id="desc" style="display:none"></h4>
    <fieldset id="tag-container" style="display:none" class="dhtml-chess-admin-fieldset">
        <legend>Usage</legend>
        <h4>
            <p>To use this board, insert the tag below into your posts:</p>
            <p>TAG: <span id="tag"
                          style="display:inline-block;border-radius:5px;padding:5px;background-color:#666;color:#fff"></span>
            </p>
            <p>Replace the value inside the angle brackets with the numeric id found in the game editor.</p>
        </h4>
    </fieldset>
    <h1>Chess board preview</h1>

    <div id="preview" style="max-width:500px;margin-top:10px"></div>
    <div id="help" style="display:none"><em>The fonts in the preview may appear different on your website depending on
            your css styles.</em></div>
</div>