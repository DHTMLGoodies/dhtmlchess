<?php
/**
 *
 * admin/partials/wp-cbf-admin-display.php - Don't add this comment
 *
 **/


function dhtmlchess_add_piece($pluginName, $type, $checkedPiece)
{
    $extension = strstr($type, "svg") ? "svg" : "png";

    $checked = $checkedPiece == $type;

    $pieces = array(
        'wp', 'wb', 'wn', 'wr', 'wq', 'wk',
        'bp', 'bb', 'bn', 'br', 'bq', 'bk',
    );
    ?>
    <tr>

        <td>
            <input value="<?php echo $type; ?>"
                   type="radio" id="<?php echo $pluginName . $type; ?>-pieces" class="<?php echo $pluginName; ?>-pieces"
                   name="<?php echo $pluginName; ?>[pieces]" <?php if ($checked) echo " checked"; ?>>
        </td>

        <td>
            <label for="<?php echo $pluginName . $type; ?>-pieces"><?php esc_attr_e($type, $pluginName); ?></label>
        </td>
        <?php
        foreach ($pieces as $piece) {
            ?>
            <td>
                <label for="<?php echo $pluginName . $type; ?>-pieces">
                    <img width="45" src="<?php echo plugins_url($pluginName) . '/api/images/' . $type . '45' . $piece . '.' . $extension; ?>">
                </label>
            </td>
            <?php
        }
        ?>
    </tr>
    <?php
}

function addThemeOptions(){

}
?>

<style type="text/css">
    legend{
        width:auto !important;
        height:auto !important;
        margin-left:5px !important;
        position:static !important;
        overflow:visible !important;

    }
    fieldset{
        border:1px solid #CCC;
        border-radius:4px;
        margin-bottom:12px;
        background-color:#DDD;
        padding:8px;
    }
</style>

<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/api/jquery/jquery-3.1.0.min.js"></script>
<script type="text/javascript">
    function showPreview(){
        var theme = $('#<?php echo $this->plugin_name; ?>-theme').val();
        var pieceLayout = $('.<?php echo $this->plugin_name; ?>-pieces:checked').val();
        var url = '<?php echo plugins_url($this->plugin_name); ?>/api/demo/theme-preview.php?theme=' + theme + '&pieces=' + pieceLayout;

        var w = window.open(url, 'themePreview');
        w.focus();
    }
</script>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <form method="post" name="dhtmlchess_options" action="options.php">
        <?php
        $options = get_option($this->plugin_name);
        do_settings_sections($this->plugin_name);

        $theme = isset($options["theme"]) ? $options["theme"] : "wood1";
        $pieces = isset($options["pieces"]) ? $options["pieces"] : "svg_bw";
        $language = isset($options["language"]) ? $options["language"] : "en";



        $themes = array(
            array('brown', 'Brown'),
            array('grey', 'Grey'),
            array('blue', 'Blue'),
            array('wood1', 'Wood 1'),
            array('wood2', 'Wood 2'),
            array('wood3', 'Wood 3'),
            array('wood4', 'Wood 4'),
            array('wood5', 'Wood 5'),
            array('wood6', 'Wood 6'),
            array('wood7', 'Wood 7'),

        );

        $languageArray = array(
            array('en', 'English'),
            array('no', 'Norsk')
        );
        ?>
        <?php settings_fields($this->plugin_name); ?>

        <fieldset>
            <legend><?php esc_attr_e('Language', $this->plugin_name); ?></legend>
            <table>
                <tr>
                    <td><label for="<?php echo $this->plugin_name; ?>-language"><?php _e('language', $this->plugin_name); ?></label></td>
                    <td>
                        <select name="<?php echo $this->plugin_name; ?>[language]"
                                id="<?php echo $this->plugin_name; ?>-language">
                            <?php
                            foreach($languageArray as $language){
                                $selected = $language[0] == $language ? " selected": "";
                                echo '<option value="'. $language[0]. '" '. $selected . '>'. $language[1] . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <a href="#" onclick="showPreview();return false"><?php _e("Show Preview", $this->plugin_name); ?></a>
                    </td>
                </tr>

            </table>
        </fieldset>
        
        
        <fieldset>
            <legend><?php esc_attr_e('Chess Theme', $this->plugin_name); ?></legend>
            <table>
                <tr>
                    <td><label for="<?php echo $this->plugin_name; ?>-theme"><?php _e('Theme', $this->plugin_name); ?></label></td>
                    <td>
                        <select name="<?php echo $this->plugin_name; ?>[theme]"
                                id="<?php echo $this->plugin_name; ?>-theme">
                            <?php
                            foreach($themes as $th){
                                $selected = $th[0] == $theme ? " selected": "";
                                echo '<option value="'. $th[0]. '" '. $selected . '>'. $th[1] . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <a href="#" onclick="showPreview();return false"><?php _e("Show Preview", $this->plugin_name); ?></a>
                    </td>
                </tr>

            </table>
        </fieldset>

        <!-- remove some meta and generators from the <head> -->
        <fieldset>
            <legend><?php esc_attr_e('Chess Pieces', $this->plugin_name); ?></legend>
            <p><?php _e("The SVG pieces are small Vector based chess pieces.", $this->plugin_name); ?> </p>
            <table>

                <?php
                dhtmlchess_add_piece($this->plugin_name, "svg_bw", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_egg", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_alpha_bw", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_alpha_egg", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_alpha_blue", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_merida", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_chessole", $pieces);


                dhtmlchess_add_piece($this->plugin_name, "merida", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "meridapale", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "kingdom", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "leipzig", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "smart", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_chess-7", $pieces);
                dhtmlchess_add_piece($this->plugin_name, "svg_darkgrey", $pieces);

                ?>

            </table>
        </fieldset>


        <?php submit_button(__('Save all changes', $this->plugin_name), 'primary', 'submit', TRUE); ?>

    </form>

</div>