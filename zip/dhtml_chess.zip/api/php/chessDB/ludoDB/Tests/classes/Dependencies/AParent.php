<?php
/**
 *
 * User: Alf Magne
 * Date: 06.02.13

 */
class AParent extends LudoDBModel
{
    protected $JSONConfig = true;
}
