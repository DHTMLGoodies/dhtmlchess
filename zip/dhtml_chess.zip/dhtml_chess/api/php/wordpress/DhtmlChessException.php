<?php

/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 26/01/2017
 * Time: 00:24
 */
class DhtmlChessException extends Exception
{

}

class DhtmlChessPgnNotFoundException extends DhtmlChessException{}
