<?php

/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 02/02/2017
 * Time: 21:40
 */
class ChessTagTests extends PHPUnit_Framework_TestCase
{

    

}