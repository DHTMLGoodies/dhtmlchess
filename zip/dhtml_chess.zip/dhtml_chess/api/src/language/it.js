chess.language = Object.merge(chess.language, {
    pieces:{
        'p':'',
        'n':'C',
        'b':'A',
        'r':'T',
        'q':'D',
        'k':'R'
    }
});