<?php
/**
 *
 * admin/partials/wp-cbf-admin-display.php - Don't add this comment
 *
 **/


function dhtmlchess_add_piece($pluginName, $type, $checked = false)
{
    $extension = strstr($type, "svg") ? "svg" : "png";

    $pieces = array(
        'wp', 'wb', 'wn', 'wr', 'wq', 'wk',
        'bp', 'bb', 'bn', 'br', 'bq', 'bk',
    );
    ?>
    <tr>

        <td>
            <input onclick="ludo.$('boardPreview').setPieceLayout('<?php echo $type; ?>')" value="<?php echo $type; ?>"
                   type="radio" id="<?php echo $pluginName . $type; ?>-pieces"
                   name="<?php echo $pluginName; ?> [pieces]" <?php if ($checked) echo " checked"; ?>>
        </td>

        <td>
            <label for="<?php echo $pluginName . $type; ?>-pieces"><?php esc_attr_e($type, $pluginName); ?></label>
        </td>
        <?php
        foreach ($pieces as $piece) {
            ?>
            <td>
                <label for="<?php echo $pluginName . $type; ?>-pieces">
                    <img width="45"
                         src="<? echo plugins_url($pluginName) . '/images/' . $type . '45' . $piece . '.' . $extension; ?>">
                </label>
            </td>
            <?
        }
        ?>

    </tr>
    <?
}


function dhtmlchess_add_square_bg($pluginName, $propName, $checked = false, $color)
{

    $squares = array(
        'lightest-wood',
        'lighter-wood',
        'light-wood',
        'red-wood',
        'red-wood2',
        'dark-wood',
        'wood-1',
        'wood-cherry',
        'darker-wood',
        'darker-wood2',
        'darkest-wood',
        'wood-bamboo',
        'black-wood',
        'grey-wood',
        'light-blue-wood',
        'none'
    );

    ?>

    <tr>


        <?php
        foreach ($squares as $index => $square) {

            if ($index == 0) $checked = true; else $checked = false;

            if ($index % 4 == 0) {
                if ($index > 0) echo "</tr>";
                echo "<tr>";
            }
            $id = $pluginName . $square . $propName;

            $src = plugins_url($pluginName) . '/images/board/' . $square . '.png';
            ?>
            <td>
                <?php
                if ($square == "none") {
                    echo "<div style='height:120px;display:inline-block'></div>";
                } else {

                    ?>
                    <label for="<?php echo $id; ?>">
                        <img height="120" src="<? echo $src ?>">
                    </label><br>
                    <?php
                }
                ?>


                <input value="<?php echo $square; ?>" type="radio" id="<?php echo $id; ?>"
                       name="<?php echo $pluginName; ?> [<?php echo $propName; ?>]"
                    <?php if ($checked) echo " checked"; ?>
                       onchange="if(this.checked){ ludo.$('boardPreview').setSquareBg('<? echo $color; ?>','<?php echo $src; ?>') }">
                <?php echo $square; ?>
            </td>
            <?php

        }

        ?>
    </tr>
    <?php

}


function dhtmlchess_add_board_bg($pluginName, $propName, $checked = false)
{

    $squares = array(
        'grey-wood-strip',
        'red-wood-strip',
        'wood-strip2',
        'wood-strip3',
        'wood-strip-dark',
        'wood-strip',
        'none'
    );

    ?>

    <tr>


        <?php
        foreach ($squares as $index => $square) {

            if ($index == 0) $checked = true; else $checked = false;

            if ($index % 4 == 0) {
                if ($index > 0) echo "</tr>";
                echo "<tr>";
            }
            $id = $pluginName . $square . $propName;

            $src = plugins_url($pluginName) . '/images/board-bg/' . $square;

            ?>
            <td>
                <?php
                if ($square == "none") {
                    echo "<div style='height:120px;display:inline-block'></div>";
                } else {

                    ?>
                    <label for="<?php echo $id; ?>">
                        <div
                            style="margin:0 auto;width:100px;height:100px;background-image:url('<?php echo $src; ?>-horizontal.png')"></div>

                    </label><br>
                    <?php
                }
                ?>


                <input value="<?php echo $square; ?>" type="radio" id="<?php echo $id; ?>"
                       name="<?php echo $pluginName; ?>
                    [<?php echo $propName; ?>]" <?php if ($checked) echo " checked"; ?>
                       onchange="if(this.checked)updateBoardBackground(this)">
                <?php echo "Wood " . ($index + 1) . ' ' . $square; ?>
            </td>
            <?php

        }

        ?>
    </tr>
    <?php

}

?>
<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/jquery/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/js/dhtml-chess-minified.js"></script>
<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/src/view/board/gui.js"></script>
<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/src/view/board/board.js"></script>
<script type="text/javascript" src="<?php echo plugins_url($this->plugin_name); ?>/src/view/board/piece.js"></script>
<link rel="stylesheet" href="<?php echo plugins_url($this->plugin_name); ?>/css/dhtml-chess-all.css" type="text/css">
<style type="text/css">
legend{
    width:auto !important;
    height:auto !important;
    margin-left:5px !important;
    position:static !important;
    overflow:visible !important;

}
    fieldset{
        border:1px solid #CCC;
        border-radius:4px;
        margin-bottom:12px;
        background-color:#DDD;
        padding:8px;
    }
</style>
<div id="dhtmlchess_preview" style="position:absolute;width:400px;height:400px">

</div>

<script type="text/javascript">
    var basePath = '<?php echo plugins_url($this->plugin_name); ?>';
    function updateBoardBackground(radio) {
        var val = $(radio).val();
        val = basePath + '/images/board-bg/' + val;
        ludo.$('boardPreview').bg.setPattern(
            val + '-horizontal.png',
            val + '-vertical.png'
        );
        console.log(val);
    }

</script>
<script type="text/javascript">

    $(window).on('scroll', moveBoard);
    $(window).on('resize', moveBoard);


    var board = $('#dhtmlchess_preview');
    $(document).ready(function () {
        moveBoard();
    });

    function moveBoard() {
        console.log($(document.body).scrollTop());
        board.css('left', board.parent().width() - board.outerWidth() - 20);
        board.css('top', $(document.body).scrollTop());
    }

    ludo.config.setDocumentRoot('../wp-content/plugins/dhtml_chess');

    var id = String.uniqueID();

    var v = new chess.view.board.Board({
        id: 'boardPreview',
        module: id,
        renderTo: '#dhtmlchess_preview',
        pieceLayout: 'svg_bw',
        animationDuration:0,
        layout: {
            width: 'matchParent',
            height: 'matchParent'
        },
        background: {
            horizontal: '../../dhtml-chess/images/transparent-dot.png',
            vertical: '../../dhtml-chess/images/transparent-dot.png',
            borderRadius: '1%'
        },
        plugins:[
            {
                type: 'chess.view.highlight.Arrow',
                styles:{
                    fill:'#0288D1',
                    stroke:'#01579B'
                }
            }
        ]
    });

    var controller = new chess.controller.Controller({
        applyTo:id
    });
    controller.getCurrentModel().appendMove('e4');

</script>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <form method="post" name="cleanup_options" action="options.php">

        <!-- remove some meta and generators from the <head> -->

        <h3><?php esc_attr_e('Chess Pieces', $this->plugin_name); ?></h3>
        <p>The SVG pieces are small Vector based chess pieces. </p>
        <table>

            <?
            dhtmlchess_add_piece($this->plugin_name, "svg_bw", true);
            dhtmlchess_add_piece($this->plugin_name, "svg_egg");
            dhtmlchess_add_piece($this->plugin_name, "svg_alpha_bw");
            dhtmlchess_add_piece($this->plugin_name, "svg_alpha_egg");
            dhtmlchess_add_piece($this->plugin_name, "svg_alpha_blue");
            dhtmlchess_add_piece($this->plugin_name, "svg_merida");
            dhtmlchess_add_piece($this->plugin_name, "svg_chessole");


            dhtmlchess_add_piece($this->plugin_name, "merida");
            dhtmlchess_add_piece($this->plugin_name, "meridapale");
            dhtmlchess_add_piece($this->plugin_name, "kingdom");
            dhtmlchess_add_piece($this->plugin_name, "leipzig");
            dhtmlchess_add_piece($this->plugin_name, "smart");
            dhtmlchess_add_piece($this->plugin_name, "svg_chess-7");

            ?>

        </table>

        <fieldset>
            <legend><span><?php esc_attr_e('Square Backgrounds', $this->plugin_name); ?></span></legend>

        <h4>White Squares</h4>
        <table>
            <?php
            dhtmlchess_add_square_bg($this->plugin_name, "white_square_background", false, 'white');
            ?>
        </table>
        <h4>Black Squares</h4>
        <table>
            <?php
            dhtmlchess_add_square_bg($this->plugin_name, "black_square_background", false, 'black');
            ?>
        </table>

            </fieldset>

        <fieldset>
            <legend><span>Square Background colors</span></legend>
            <p>If background picture is selected above, you can skip specifying colors.</p>

            <label for="<?php echo $this->plugin_name; ?>-white_squares_bgcolor">
                <span><?php esc_attr_e('White Squares', $this->plugin_name); ?></span>
            </label>
            <input type="text" id="<?php echo $this->plugin_name; ?>-white_squares_bgcolor"
                   name="<?php echo $this->plugin_name; ?> [white_squares_bgcolor]" placeholder="#RRGGBB color value"/>
            <br>
            <label for="<?php echo $this->plugin_name; ?>-black_squares_bgcolor">
                <span><?php esc_attr_e('Black Squares ', $this->plugin_name); ?></span>
            </label>
            <input type="text" id="<?php echo $this->plugin_name; ?>-black_squares_bgcolor"
                   name="<?php echo $this->plugin_name; ?> [black_squares_bgcolor]" placeholder="#RRGGBB color value"/>
        </fieldset>

        <!--
        <fieldset>
            <legend><span>Clean WordPress head section</span></legend>
            <label for="<?php echo $this->plugin_name; ?>-cleanup">
                <input type="checkbox" id="<?php echo $this->plugin_name; ?>-cleanup"
                       name="<?php echo $this->plugin_name; ?> [cleanup]" value="1"/>
                <span><?php esc_attr_e('Clean up the head section', $this->plugin_name); ?></span>
            </label>
        </fieldset>

        -->

        <fieldset>
            <legend><span>Board background</span></legend>
            <label for="<?php echo $this->plugin_name; ?>-board_border_radius">
                <span><?php esc_attr_e('Border radius in percent of board size or in pixels', $this->plugin_name); ?></span>
            </label>
            <input type="text" id="<?php echo $this->plugin_name; ?>-board_border_radius"
                   name="<?php echo $this->plugin_name; ?> [board_border_radius]"
                   placeholder="Number or Percent"/
            onchange="if(this.value.length)ludo.$('boardPreview').bg.setBorderRadius(this.value)">



        <table>
            <?php
            dhtmlchess_add_board_bg($this->plugin_name, "board_bg", false);
            ?>
        </table>

        </fieldset>


        <?php submit_button('Save all changes', 'primary', 'submit', TRUE); ?>

    </form>

</div>