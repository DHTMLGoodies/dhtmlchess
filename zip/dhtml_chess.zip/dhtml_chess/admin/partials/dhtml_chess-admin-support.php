<style type="text/css">
    li{
        margin-left:20px;
        list-style-type: disc;

    }
</style>
<h1><?php echo __("DHTML Chess Support"); ?></h1>

<h2><?php echo __("How to Use"); ?></h2>
<p><?php echo __("Insert short tags into your posts using the format below. You can preview the tags from the"); ?> <strong><?php echo __("Shorttags"); ?></strong> <?php echo __("menu item"); ?>.</p>
<p>This are the available tags:</p>
<ul>

<li><strong>[chess &lt;properties>]</strong></li>
<li><strong>[fen &lt;properties>]&lt;fen string>[/fen]</strong></li>
<li><strong>[pgn &lt;properties>]&lt;pgn string>[/fen]</strong></li>
</ul>
<h3><?php echo __("Samples"); ?></h3>
<p>[chess db="1" tpl="1"] : <?php echo __("Show games from pgn database 1 using view template 1"); ?> <br>
[chess game="100" tpl="5"] : <?php echo __("Show game with id 100, using game template 5"); ?> <br>
[chess game="100" tpl="5" theme="brown"] : <?php echo __("Same as above, but override default template"); ?>. <br>
[fen]k1K5/p7/P1N5/1P6/4pP2/2p1P3/pp6/r3Q3 w - - 0 1[/fen] : <?php echo __("Show board with this"); ?> <a href="https://en.wikipedia.org/wiki/Forsyth%E2%80%93Edwards_Notation" onclick="var w = window.open(this.href);return false"><?php echo __("fen position"); ?></a><br>


</p>
<h3><?php echo __("Properties"); ?></h3>
<p><?php echo __("These are the available properties"); ?>:</p>
<ul>
    <li><strong>db="&lt;id>"</strong>: <?php echo __("Which database to show games from. Database id's are highlighted in the game editor. When rendering games from a database, WordPressChess will use a template where you can choose which games to show on the board from a list"); ?>.</li>
    <li><strong>game="&lt;id>"</strong>: <?php echo __("Id of game to show. Game id's are also highlighted in the game editor"); ?>.</li>
    <li><strong>tactics=1</strong>: <?php echo __("Set this property to show tactic puzzles using the games defined in the db property."); ?>.</li>
    <li><strong>tpl="&lt;template number>"</strong>: <?php echo __("Which template to choose when rendering the board. There are different templates to choose from for game and database views. Example: to show a game using the fifth game template, set tpl to \"5\". The different templates can be previews from the shorttags menu item"); ?>.</li>
    <li><strong>theme="&lt;theme name>"</strong>: <?php echo __("Optional property which lets you override default theme") ?>.</li>
    <li><strong>width="&lt;width>"</strong>: <?php echo __("Optional width which is only set on large screens") ;?>.</li>
    <li><strong>float="&lt;left|right>"</strong>: <?php echo __("Optional attribute for positioning the board when width is less than 100%. This option is also only applied to large screens"); ?>.</li>
    <li><strong>css="float:left;width:70%"</strong>: <?php echo __("Optional CSS styling"); ?>.</li>
    <li><strong>sound=1</strong>: <?php echo __("1 to enable sound effects . Default = 0 (no sounds)"); ?>.</li>
    <li><strong>heading_tpl="&lt;Your template string>"</strong>: <?php echo __("Template string for the headings. Example: headingTpl=\"{white} vs {black}\". The curly braces are placedholders for game metadata. If you look at the pgn below, game metadata are setup, eventdata, white, black etc. i.e. all the properties defined before the moves. The keys should always be in lowercase. Default headingTpl is usually \"{white} vs {black}\", but this may vary based on the template."); ?>.</li>
    <li><strong>random=1</strong>: <?php echo __("Optional property for Tactic Puzzles. If set, random games will be pulled from the database. The default behaviour is to show the games in sequence. For opening training, this could be a useful setting."); ?>.</li>
    <li><strong>sofiaRules=1</strong>: <?php echo __("True to enable Sofia Rules when generating leaderboards for tournaments (3 points for 1, 1 point for draw)"); ?>.</li>
</ul>

<h2><?php echo __("Tactic Puzzles"); ?></h2>
<p><?php echo __("Boards with drag'n drop capabilities can be shown by setting the property <strong>tactics</strong> to 1 as seen above"); ?>.</p>
<p>Example:</p>
<pre>[chess tactics="1" db="2"]</pre>
<p>This will show a tactics board where the games are picked from the database with ID 2. </p>
<p>Games used for tactic puzzles are created from PGN's like:</p>
<pre>
[setup "1"]
[eventdate "1998.??.??"]
[castle "1"]
[index "12"]
[ts "1487793876140"]
[event " White to move."]
[site "?"]
[date "1998.??.??"]
[round "?"]
[white "White mates in 5"]
[black "White mates in 5 1001 Brilliant Ways to Checkmate"]
[result "1-0"]
[fen "r3k1nr/pp1n2pp/1bp1N1q1/6B1/2B1p3/8/PPP2RPP/R2Q3K w kq - 0 1"]
[plycount "9"]


1. Qxd7+  Kxd7 2. Rd1+  Kc8 3. Rf8+  Qe8 4. Rxe8+  Bd8 5. Rdxd8# (5. Rexd8#)     
</pre>
<p>As you can see, the game has a custom start position(fen) and contains all the moves required for a correct solution. In this example, there are two available checkmate moves in the end. This is
indicated by the variation 5. Rdxd8# (5. Rexd8#).</p>
<p>The easiest way to show tactic puzzles is to upload a PGN containing a collection of games like above. </p>
<p>You can also use tactics for opening training. Upload an </p>
<h2><?php echo __("Import PGN"); ?></h2>
<p><?php echo __("PGN files can be imported from the <strong>Import PGN</strong> menu item. The PGN will be saved on the server as a game database which you can render games from using the [chess] shorttag"); ?>.</p>
<h2><?php echo __("Archive Database"); ?></h2>
<p><?php echo __("If you have a lot of databases, you can hide the ones you don't use often by archiving them"); ?>.</p>
<p><?php echo __("You archive a database using swipe right gestures from the list of databases in the game editor"); ?>.</p>
<p><?php echo __("An Archived database is still available, but it won't show up in the game editor. An archived database can later be made available from the <strong>Archived databases</strong> admin page"); ?>.</p>

<h2><?php echo __("Delete a Database"); ?></h2>
<p><?php echo __("If you want to permanently delete a database, you will first have to archive it, then delete it from the list of archived databases by swiping left on the database in the list"); ?>.</p>

<h2><?php echo __("The Game Editor"); ?></h2>
<p><?php echo __("The Game Editor let's you edit games online and make them available on your web page"); ?>.</p>
<p><?php echo __("Here are some of the key features of the editor"); ?>:</p>
<ul>
    <li><?php echo __("Support for saving drafts. A draft is not available from the web page. You can work on a draft as long as you want, and once it's ready, you can publish it in a database"); ?>.</li>
    <li><?php echo __("Support for StockfishJS. Stockfish JS is a Javascript version of Stockfish. It is a fairly strong engine, but not as efficent as other native Chess Engines since it's running in the browser. From the Engine Analysis, you can append the engine analysis as variations to your games and also append computer eval as a comment"); ?>. </li>
    <li><?php echo __("Online Annotations - The Game Editor has a feature for annotating the games"); ?>.</li>
</ul>

<h2><?php echo __("DHTML Chess Forums"); ?></h2>
<p><?php echo __("WordPressChess is a plugin based on DHTML Chess from dhtmlchess.com"); ?>.</p>
<p><?php echo __("For more help, visit"); ?> <a href="http://www.dhtmlchess.com/forums" onclick="var w=window.open(this.href);return false">dhtmlchess.com/forums</a></p>