<?php
if ( isset( $_GET['m'] ) )
{
    ?>
    <div id='message' class='updated fade'><p><strong>PGN successfully imported into <?php echo $_GET['m']; ?> (ID: <?php echo $_GET["pgn_id"]; ?>).</strong></p></div>
    <?php
}
if ( isset( $_GET['e'] ) )
{
    ?>
    <div id='message' class='error fade'><p><strong>Could not import selected PGN file.</strong></p></div>
    <?php
}

update_option("dhtml_chess_db_installed", 0);
update_option("dhtml_chess_db_version", 1);



?>
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>

    <form method="post" name="dhtml_chess_importpgn" action="admin-post.php" enctype="multipart/form-data">
        <input type="hidden" name="action" value="dhtml_chess_import_pgn" />
        <input type="file" name="pgn" accept=".pgn"><br>
        <input type="text" name="pgn_title" placeholder="Optional name">
        <p>If name is left empty, the pgn file name will be the name of the database.</p>


        <?php wp_nonce_field( 'dhtml_chess_importpgn', '_nonce_dhtml_chess' ); ?>
        <?php submit_button(__('Import', $this->plugin_name), 'primary', 'submit', TRUE); ?>
        <p><em>For large PGN files, the import may take some time</em></p>

    </form>

</div>