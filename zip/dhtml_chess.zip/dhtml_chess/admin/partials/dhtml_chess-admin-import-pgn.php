<?php
if ( isset( $_GET['m'] ) )
{
    ?>
    <div id='message' class='updated fade'><p><strong><?php echo __("PGN successfully imported into"); ?> <?php echo $_GET['m']; ?> (ID: <?php echo $_GET["pgn_id"]; ?>).</strong></p></div>
    <?php
}
if ( isset( $_GET['e'] ) )
{
    ?>
    <div id='message' class='error fade'><p><strong><?php echo __("Could not import selected PGN file"); ?>.</strong></p></div>
    <?php
}

update_option("dhtml_chess_db_installed", 0);
update_option("dhtml_chess_db_version", 1);



?>
<div class="wrap">
    <script type="text/javascript">
        function disableButton(btn){
            var btn = jQuery('#submit-button');
            var a = function(){
                jQuery('#submit-button').prop("disabled", true);
            };
            setTimeout(a, 100);
            btn.val("Importing");

            jQuery('#spinning-wheel').css('visibility', 'visible')

        }

    </script>
    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>

    <form method="post" name="dhtml_chess_importpgn" action="admin-post.php" enctype="multipart/form-data">
        <input type="hidden" name="action" value="dhtml_chess_import_pgn" />
        <input type="file" name="pgn" accept=".pgn"><br>
        <input type="text" name="pgn_title" placeholder="<?php echo __("Optional db name"); ?>">
        <p><?php echo __("If name is left empty, the pgn file name will be the name of the database"); ?>.</p>


        <?php wp_nonce_field( 'dhtml_chess_importpgn', '_nonce_dhtml_chess' ); ?>
        <?php submit_button(__('Import', $this->plugin_name), 'primary', 'submit', false, array(
                "onclick" => 'disableButton()', "id" => "submit-button"
        )); ?>
        <img id="spinning-wheel" src="images/spinner.gif" style="visibility:hidden">
        <p><em><?php echo __("For large PGN files, the import may take some time"); ?></em></p>
    </form>
</div>