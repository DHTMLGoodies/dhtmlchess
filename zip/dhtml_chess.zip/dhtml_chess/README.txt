=== DHTML Chess ===
Contributors: batalf
Donate link: http://www.dhtmlchess.com
Tags: chess, chess games
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: 4.7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Chess for your WordPress site.

== Description ==

An online chess database with beautiful layout for your WordPress site.

* Lots of templates to choose from
* Choose between simple game views, tournament views and tactics.
* Have your games stored in a database
* Import your PGN files with the click of a button.
* Analyse your games online using StockfishJS embedded in the browser(No installation required).

== Installation ==

See http://wordpresschess.com/install-beta/

== Frequently Asked Questions ==

= How to update the plugin =

The plugin is updated automatically like other plugins

== Screenshots ==

1. Online Game Editor.
2. Many board templates

== Upgrade Notice ==

= 1.0.21 =

== Changelog ==

= 1.0.49
* Support for arrows and highlighted squares for the [fen] short code.

= 1.0.25 =
* Previous game button for tactics puzzles
* Bugfixes

= 1.0.21 =
* Support for Undo/Redo(Ctrl/Command+Z, Ctrl/Command+Shift+Z) in the Game Editor
* Support for Saving using Ctrl/Command+S in the game editor
* Paging of games in the editor