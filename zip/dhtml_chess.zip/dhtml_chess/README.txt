=== Plugin Name ===
Contributors: batalf
Donate link: http://www.dhtmlchess.com
Tags: chess, chess games
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: 4.7.2
License: GPLv2 or later, Commercial(http://www.dhtml-chess.com/license.php)
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Chess for your WordPress site.

== Description ==

WordPressChess brings Chess Analysis to your WordPress chess site.

* Lots of templates to choose from
* Choose between simple game views, tournament views and tactics.
* Have your games stored in a database
* Import your PGN files with the click of a button.
* Analyse your games online using StockfishJS embedded in the browser(No installation required).

== Installation ==

See http://wordpresschess.com/install-beta/

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. Online Game Editor.
2. Many board templates

== Changelog ==

= 1.0.1 =
* Support for Undo/Redo(Ctrl/Command+Z, Ctrl/Command+Shift+Z) in the Game Editor
* Support for Saving using Ctrl/Command+S in the game editor
