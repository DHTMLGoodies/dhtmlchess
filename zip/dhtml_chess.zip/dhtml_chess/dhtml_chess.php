<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://www.dhtmlchess.com
 * @since             1.0.0
 * @package           Dhtml_chess
 *
 * @wordpress-plugin
 * Plugin Name:       DHTML Chess
 * Plugin URI:        http://wordpresschess.com
 * Description:       Display Chess Games and Chess tactic puzzles on your website.
 * Version:           1.0.5
 * Author:            dhtmlchess.com
 * Author URI:        http://www.dhtmlchess.com
 * License:           GPL-2.0+ or Commercial
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       dhtml_chess
 * Domain Path:       /languages
 */

define("DHTML_CHESS_VERSION", "1.0.5");

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}


add_option("dhtml_chess_db_version", 1);
add_option("dhtml_chess_db_installed_2", 0);

require 'plugin-update-checker/plugin-update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
    'http://dhtmlchess.com/api/wordpress_dhtml_chess.json',
    __FILE__,
    'dhtml_chess'
);

// Update this when database changes has been done
$dhtml_chess_db_version = 3;

require_once plugin_dir_path(__FILE__) . 'api/autoload.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-dhtml_chess-activator.php
 */
function activate_dhtml_chess()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-dhtml_chess-activator.php';
    require_once plugin_dir_path(__FILE__) . 'includes/class-dhtml_chess-upgrade.php';
    Dhtml_chess_Activator::activate();
}

function uninstall_dhtml_chess()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-dhtml_chess-uninstall.php';
    Dhtml_chess_Uninstall::uninstall();
}

function dhtml_chess_update_db_check()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-dhtml_chess-upgrade.php';
    Dhtml_chess_Upgrade::upgrade();
}

register_activation_hook(__FILE__, 'activate_dhtml_chess');
# register_deactivation_hook(__FILE__, 'deactivate_dhtml_chess');
register_uninstall_hook(__FILE__, 'uninstall_dhtml_chess');
add_action('plugins_loaded', 'dhtml_chess_update_db_check');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-dhtml_chess.php';


/**
 * Handling short tags
 */
error_reporting(E_ALL);
ini_set("display_errors", "on");
add_shortcode("fen", "shortcode_handler");
add_shortcode("pgn", "shortcode_handler");
add_shortcode("chess", "shortcode_handler");


$scriptsWritten = false;

function getLanguage()
{
    $jsWords = array();
    $words = array("Add comment", "Add comment after", "Add comment before", "Annotate", "Append Line", "Archive Database", "Are you sure you want to discard this draft?", "Black", "Cancel", "Castling", "Clear", "Computer Eval", "Could not load game. Try again later", "Database", "Date", "Delete", "Delete Move", "Discard", "Discard draft", "Draft Saved", "Draft discarded", "Edit metadata", "En passant", "Engine stopped", "Event", "Everything is up to date", "FEN", "From elo", "Game", "Game Comment", "Game Drafts", "Game Saved", "Game published", "Game saved successfully", "Games", "Games in Database: ", "Good job! You have solved this puzzle. Click OK to load next game", "Good move", "Hint", "Import games(PGN)", "Invalid Fen", "Invalid game", "Invalid grade", "Invalid move", "Invalid position", "Last moves", "Load fen", "Loading drafts...", "Loading game", "Loading games...", "Metadata", "Move updated to", "Moving", "Name of new database", "New Database", "New Database created", "New Game", "New Game Database", "New Position", "Next Game", "No Databases found", "No Drafts Found", "No games", "OK", "Overwrite", "PGN Databases", "PGN archived", "PGN deleted", "PGN restored", "PGN:", "Paste fen into the text box below", "Player Black", "Player White", "Ply", "Poor move", "Position setup", "Publish", "Publish Game", "Publish game in", "Questionable move", "Rated", "Restore", "Result", "Round", "Save", "Save Draft", "Save Eval", "Save game", "Search", "Select PGN", "Selected", "Side to move", "Site", "Solution", "Speculative move", "Standings", "Start", "StockFish.JS Engine", "Time", "To elo", "Undo", "Update", "Variation", "Very good move", "Very poor move", "Well done - Puzzle complete", "White", "Wrong move - please try again", "You have unsaved game data. Do you want to discard these?", "commandWelcome", "command_", "to move");
    foreach ($words as $word) {
        $jsWords[] = 'chess.language["' . $word . '"] = "' . __($word, "dhtml_chess") . '";';
    }
    $content = '<script type="text/javascript">jQuery(document).ready(function(){' . implode("", $jsWords) . '});</script>';
    return $content;
}


function shortcode_handler($attributes, $content = null, $tag)
{

    global $dhtml_config_added;
    try {

        if(!empty($attributes) && isset($attributes["ignore"])){

            $ret = '[' . $tag;

            foreach($attributes as $key=>$val){
                if($key != "ignore"){
                    $ret.=' ' . $key . '="' . $val . '"';
                }
            }

            $ret .=']';

            if(!empty($content)){
                $ret .=$content.'[/'. $tag . ']';
            }

            return $ret;

        }

        $plugin_name = "dhtml_chess";
        $version = DHTML_CHESS_VERSION;

        $options = get_option($plugin_name);

        $theme = !empty($options['theme']) ? $options['theme'] : "grey";

        wp_localize_script('ajax-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php'), 'we_value' => 1234));

        wp_enqueue_style($plugin_name, plugin_dir_url(__FILE__) . '/api/css/dhtml-chess-wordpress-minified.css', array(), $version, 'all');
        wp_enqueue_script($plugin_name, plugin_dir_url(__FILE__) . '/api/js/dhtml-chess-wordpress-minified.js', array("jquery"), $version, false);
        wp_enqueue_style($plugin_name . 'override', plugin_dir_url(__FILE__) . '/api/themes/overrides.css', array(), $version, 'all');
        wp_enqueue_style($plugin_name . 'themecss', plugin_dir_url(__FILE__) . '/api/themes/' . $theme . '.css', array(), $version, 'all');
        wp_enqueue_script($plugin_name . "theme", plugin_dir_url(__FILE__) . '/api/themes/' . $theme . '.js', array(), $version, false);

        wp_enqueue_script($plugin_name . "1", plugin_dir_url(__FILE__) . '/api/src/wp-public/wordpress-templates-minified.js', array(), $version, false);
        wp_enqueue_script($plugin_name . "2", plugin_dir_url(__FILE__) . '/api/src/wp-public/computer/comp1.js', array(), $version, false);
        # wp_enqueue_script($plugin_name . "game5", plugin_dir_url(__FILE__) . '/api/src/wp-public/game/game5.js', array(), $version, false);

        $prefix = "";
        if (empty($dhtml_config_added)) {
            $dhtml_config_added = true;
            $pieces = !empty($options['pieces']) ? $options['pieces'] : "svg_bw";

            $prefix = getLanguage() . ' <script type="text/javascript">
            // Chess For Wordpress www.dhtmlchess.com
            jQuery(document).ready(function(){
                    if(chess.THEME)chess.THEME["chess.view.board.Board"].pieceLayout="' . $pieces . '";
                    ludo.config.setUrl("' . admin_url('admin-ajax.php') . '");
                    ludo.config.setDocumentRoot("' . plugins_url($plugin_name . "/api/", $plugin_name) . '/");
            });
            </script>';
        };

        $docRoot = plugins_url($plugin_name . "/api/", $plugin_name);
        $handler = new DhtmlChessViews();

        if (empty($attributes)) {
            $attributes = array();
        }
        if (empty($attributes["tpl"])) {
            $attributes["tpl"] = 1;
        }
        if ($tag == "fen") {
            $view = $handler->getParsedTagFromAttributes("fen", $attributes, $content);
            return $prefix . $view->getJS($docRoot);
        } else if ($tag == "pgn") {
            $view = $handler->getParsedTagFromAttributes("pgn", $attributes, $content);
            return $prefix . $view->getJS($docRoot);
        } else {
            $view = $handler->getParsedTagFromAttributes("chess", $attributes, $content);
            return $prefix . $view->getJS($docRoot);
        }

    } catch (Exception $e) {
        $dhtml_config_added = false;
        return "";
    }
}


add_action('admin_post_dhtml_chess_import_pgn', 'import_pgn');

add_action('wp_ajax_get_standings', 'get_standings');
add_action('wp_ajax_nopriv_get_standings', 'get_standings');
add_action('wp_ajax_count_games', 'count_games');
add_action('wp_ajax_get_draft', 'get_draft');
add_action('wp_ajax_discard_draft', 'discard_draft');
add_action('wp_ajax_save_draft', 'save_draft');
add_action('wp_ajax_list_drafts', 'list_drafts');
add_action('wp_ajax_random_game', 'random_game');
add_action('wp_ajax_nopriv_random_game', 'random_game');
add_action('wp_ajax_game_by_index', 'game_by_index');
add_action('wp_ajax_nopriv_game_by_index', 'game_by_index');
add_action('wp_ajax_game_by_id', 'game_by_id');
add_action('wp_ajax_nopriv_game_by_id', 'game_by_id');
add_action('wp_ajax_list_pgns', 'list_pgns');
add_action('wp_ajax_nopriv_list_pgns', 'list_pgns');
add_action('wp_ajax_list_of_games', 'list_of_games');
add_action('wp_ajax_nopriv_list_of_games', 'list_of_games');
add_action('wp_ajax_delete_game', 'delete_game');
add_action('wp_ajax_save_game', 'save_game');
add_action('wp_ajax_publish_game', 'publish_game');
add_action('wp_ajax_archive_pgn', 'archive_pgn');
add_action('wp_ajax_new_pgn', 'new_pgn');
add_action('wp_ajax_list_archived', 'list_archived');
add_action('wp_ajax_restore_pgn', 'restore_pgn');
add_action('wp_ajax_delete_pgn', 'delete_pgn');
add_action('wp_ajax_rename_pgn', 'rename_pgn');


$start_time = microtime(true);


function canEditDhtmlChess()
{
    return true;
}


function import_pgn()
{

    /*
     * {"pgn":{"name":"art_attack.pgn","type":"application\/octet-stream","tmp_name":"\/private\/var\/tmp\/phpGyfato","error":0,"size":60118}}
     */
    if (canEditDhtmlChess() && isset($_FILES['pgn'])) {

        check_admin_referer('dhtml_chess_importpgn', '_nonce_dhtml_chess');

        try {


            $pgn = $_FILES['pgn'];

            if (empty($_FILES['pgn']) || empty($pgn["tmp_name"])) {
                throw new DhtmlChessException("No file");
            }
            $name = empty($_POST['pgn_title']) ? $pgn["name"] : $_POST['pgn_title'];

            $pgnContent = file_get_contents($pgn["tmp_name"]);
            $importer = new DhtmlChessImportPgn();
            $pgn = $importer->importPgnStringToDatabase($name, $pgnContent);

            if (!empty($pgn)) {
                if (wp_redirect(admin_url(esc_url_raw('admin.php?page=dhtml_chess_import_pgn&m=' . $pgn->getName() . "&pgn_id=" . $pgn->getId())))) {
                    exit;
                };

            }

        } catch (DhtmlChessException $e) {
            if (wp_redirect(admin_url(esc_url_raw('admin.php?page=dhtml_chess_import_pgn&e=1')))) {
                exit;
            };

        }

        if (wp_redirect(admin_url(esc_url_raw('admin.php?page=dhtml_chess_import_pgn&e=1')))) {
            exit;
        };
    }
    wp_die();
}


/**
 * @param DhtmlChessException $exception
 */
function outputError($exception)
{
    header("content-type: Application/json");
    $message = "Error: " . $exception->getMessage();
    $data = array("success" => false, "response" => $message);
    echo json_encode($data);
}

function outputContent($jsonString)
{
    header("content-type: Application/json");
    global $start_time;
    $elapsed = microtime(true) - $start_time;

    echo '{"success" : true, "time": ' . $elapsed . ', "response":' . $jsonString . '}';
}

function get_standings()
{
    error_reporting(E_ALL);
    ini_set('display_errors', 'on');
    if (!isset($_POST['pgn'])) {
        throw new DhtmlChessException("Missing pgn attribute");
    }
    $db = new DhtmlChessDatabase();
    outputContent($db->getStandings($_POST["pgn"]));
    wp_die();
}


function list_drafts()
{
    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->allDrafts());
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function count_games()
{
    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->countGamesInDatabase());
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function get_draft()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (!isset($_POST['draft_id'])) {
            throw new DhtmlChessException("Missing draft_id");
        }
        $db = new DhtmlChessDatabase();
        outputContent($db->getDraft($_POST['draft_id']));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function list_archived()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        $db = new DhtmlChessDatabase();
        outputContent($db->listOfArchivedPgns());
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function restore_pgn()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (empty($_POST['pgn'])) {
            throw new DhtmlChessException("PGN not set");
        }

        $pgnId = preg_replace("/[^0-9]/si", "", $_POST["pgn"]);
        if (empty($pgnId)) {
            throw new DhtmlChessException("Invalid pgn id");
        }

        $db = new DhtmlChessDatabase();
        outputContent($db->restoreArchived($pgnId));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function rename_pgn()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (empty($_POST['pgn'])) {
            throw new DhtmlChessException("PGN not set");
        }
        if (empty($_POST['name'])) {
            throw new DhtmlChessException("PGN not set");
        }

        $newName = trim($_POST['name']);

        $pgnId = preg_replace("/[^0-9]/si", "", $_POST["pgn"]);
        if (empty($pgnId)) {
            throw new DhtmlChessException("Invalid pgn id");
        }

        $db = new DhtmlChessDatabase();
        $pgn = $db->rename($pgnId, $newName);
        outputContent($pgn->asJSON());

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function delete_pgn()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (empty($_POST['pgn'])) {
            throw new DhtmlChessException("PGN not set");
        }

        $pgnId = preg_replace("/[^0-9]/si", "", $_POST["pgn"]);
        if (empty($pgnId)) {
            throw new DhtmlChessException("Invalid pgn id");
        }

        $db = new DhtmlChessDatabase();
        outputContent($db->deletePgn($pgnId));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}


function new_pgn()
{
    error_reporting(E_ALL);
    ini_set('display_errors', 'on');
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (!isset($_POST['pgn_name'])) {
            throw new DhtmlChessException("Missing pgn name");
        }
        $db = new DhtmlChessDatabase();
        $pgn = $db->createDatabase($_POST['pgn_name']);

        outputContent($pgn->getId());
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}

function archive_pgn()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (!isset($_POST['pgn'])) {
            throw new DhtmlChessException("Missing pgn");
        }

        $db = new DhtmlChessDatabase();
        $pgn = preg_replace("/[^0-9]/si", "", $_POST['pgn']);
        if (empty($pgn)) {
            throw new DhtmlChessException("Missing pgn");
        }
        $success = $db->archivePgn($pgn);
        if ($success) {
            outputContent($success);
        } else {
            throw new DhtmlChessException("Unable to archive - no rows updated");
        }

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function discard_draft()
{

    try {
        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        $draftId = !empty($_POST['draft_id']) ? $_POST['draft_id'] : '';

        $draftId = preg_replace("/[^0-9]/si", "", $draftId);

        if (empty($draftId)) {
            throw new DhtmlChessException("Unable to delete - draft_id missing");
        }

        $db = new DhtmlChessDatabase();
        $countDeleted = $db->deleteDraft($draftId);

        if ($countDeleted > 0) {
            outputContent($countDeleted);
        } else {
            throw new DhtmlChessException("Could not find draft_id");
        }

    } catch (DhtmlChessException $e) {
        outputError($e);
    }

    wp_die();
}

function publish_game()
{
    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        if (!isset($_POST['pgn'])) {
            throw new DhtmlChessException("Missing destination pgn");
        }
        if (!isset($_POST['game'])) {
            throw new DhtmlChessException("Missing game");
        }

        $game = stripslashes($_POST['game']);
        $game = json_decode($game, true);
        $db = new DhtmlChessDatabase();
        $id = $db->publishDraft(json_encode($game), $_POST['pgn']);


        outputContent($id);
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}


function save_game()
{
    error_reporting(E_ALL);
    ini_set('display_errors', 'on');

    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        $db = new DhtmlChessDatabase();

        if (!isset($_POST['game'])) {
            throw new DhtmlChessException("Game data missing");

        }


        $game = $_POST['game'];
        $game = stripslashes($game);
        $game = json_decode($game, true);

        if (!empty($_POST['pgn'])) {
            $pgn = $_POST['pgn'];
        } else {
            $pgn = isset($game['pgn']) ? $game['pgn'] : null;
        }

        if (empty($pgn)) {
            throw new DhtmlChessException("Name of pgn for game to saved missing");
        }

        $db->updateGame($pgn, json_encode($game));


        outputContent($game['id']);

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}


function save_draft()
{

    error_reporting(E_ALL);
    ini_set('display_errors', 'on');

    try {

        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access Denied");
        }

        $game = stripslashes($_POST['game']);
        $game = json_decode($game, true);
        $db = new DhtmlChessDatabase();
        $draftId = $db->saveDraft(json_encode($game));
        $response = array("draft_id" => $draftId);

        outputContent(json_encode($response));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();

}


function random_game()
{

    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->randomGame($_POST["pgn"]));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function list_of_games()
{
    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->listOfGames($_POST["pgn"]));
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function game_by_index()
{


    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->gameByIndex($_POST["pgn"], $_POST["index"]));

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function game_by_id()
{
    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->gameById($_POST["id"]));

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}

function list_pgns()
{
    try {
        $db = new DhtmlChessDatabase();
        outputContent($db->listOfPgns());

    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}


function delete_game()
{
    try {
        if (!canEditDhtmlChess()) {
            throw new DhtmlChessException("Access denied");
        } else {
            if (!isset($_POST['pgn'])) {
                throw new DhtmlChessException("Missing pgn attribute");
            }
            if (!isset($_POST['id'])) {
                throw new DhtmlChessException("Missing id");
            }

            $db = new DhtmlChessDatabase();
            $count = $db->deleteGame($_POST['pgn'], $_POST["id"]);
            return json_encode(array("success" => $count > 0));
        }
    } catch (DhtmlChessException $e) {
        outputError($e);
    }
    wp_die();
}


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_dhtml_chess()
{

    $plugin = new Dhtml_chess();
    $plugin->run();

}

run_dhtml_chess();
