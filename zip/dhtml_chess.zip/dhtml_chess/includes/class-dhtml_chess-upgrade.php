<?php
/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 31/01/2017
 * Time: 22:43
 */

class Dhtml_chess_Upgrade{

    public static function upgrade() {

        global $dhtml_chess_db_version;

        $installed = get_site_option( 'dhtml_chess_db_installed' );

        if ($installed && get_site_option( 'dhtml_chess_db_version' ) != $dhtml_chess_db_version) {

            update_option( "dhtml_chess_db_version", $dhtml_chess_db_version );

            $installer = new DhtmlChessInstaller();
            $installer->upgrade(get_site_option( 'dhtml_chess_db_version' ), $dhtml_chess_db_version );

        }
    }
}