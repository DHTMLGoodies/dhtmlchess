<?php
/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 31/01/2017
 * Time: 22:40
 */

class Dhtml_chess_Uninstall{

    public static function uninstall() {

        
        $installer = new DhtmlChessInstaller();
        $installer->uninstall();

        update_option( "dhtml_chess_db_installed", 0);

    }
}