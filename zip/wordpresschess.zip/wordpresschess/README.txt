=== DHTML Chess ===
Contributors: batalf
Donate link: https://wordpresschess.com/donate/
Tags: chess, chess games
Requires at least: 3.0
Tested up to: 4.7.3
Stable tag: 4.7.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Chess for your WordPress site.

== Description ==

Everything you need to show chess games and chess puzzles on your WordPress site.

Features:

* Many templates to choose from
* Choose between simple game views, tournament views and tactics
* Have your games stored in a database
* Import your PGN files with the click of a button.
* Analyse your games online using StockfishJS embedded in the browser(No installation required).

== Installation ==

* Upload wordpresschess.zip as a plugin in WordPress admin
* Activate the plugin
* Enter your license key in

== Frequently Asked Questions ==

= How to update the plugin =

You update the plugin from the plugins page in your WP-admin.

== Screenshots ==

1. Online Game Editor.
2. Board templates

== Upgrade Notice ==


== Changelog ==

= 1.0.56 =
* Renamed to wordpresschess
* Integrated license keys

= 1.0.51 =
* Support for auto generated leaderboards

= 1.0.49
* Support for arrows and highlighted squares for the [fen] short code.

= 1.0.25 =
* Previous game button for tactics puzzles
* Bugfixes

= 1.0.21 =
* Support for Undo/Redo(Ctrl/Command+Z, Ctrl/Command+Shift+Z) in the Game Editor
* Support for Saving using Ctrl/Command+S in the game editor
* Paging of games in the editor