<?php

/**
 * Fired during plugin activation
 *
 * @link       http://www.dhtmlchess.com
 * @since      1.0.0
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wordpresschess
 * @subpackage Wordpresschess/includes
 * @author     Alf Magne Kalleland <alf.magne.kalleland@gmail.com>
 */
class Wordpresschess_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$installed = get_site_option( 'dhtml_chess_db_installed_2' );

		if(empty($installed)){
			$installer = new DhtmlChessInstaller();
			$installer->install();

			update_option( "dhtml_chess_db_installed", 1 );

		}

	}

}
