<?php
$id = uniqid();

$dhtml_chess_debug = false;

echo DhtmlChessViews::getTranslatedJSStrings($this->plugin_name);

$content = '
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'js/dhtml-chess.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/editor.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/metadata/game.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/notation/panel.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/dialog/comment.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/board/gui.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/board/board.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/board/piece.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/board/piece.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/score/bar.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/buttonbar/bar.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/pgn/parser.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/gamelist/grid.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/position/dialog.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/view/position/side-to-move.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/pgn-parser-view.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/wordpress-message.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/game-metadata.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/game-list-grid.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/publish-dialog.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/drafts.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/draft-list-view.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/comment-view.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/discard-draft-dialog.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/pgn-standings.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/draft-button.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/publish-button.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/update-game-button.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/editor-heading.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/metadata-title.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/discard-draft-button.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/new-database-dialog.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/computer-eval.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/rename-database-dialog.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/remote/reader.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/remote/game-reader.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/datasource/pgn-games.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/datasource/game-list.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/game-list.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/game-list-grid.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/pgn-list.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress/pgn-list-view.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/controller/controller.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/controller/analysis-controller.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/controller/stockfish-engine-controller.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/controller/analysis-engine-controller.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/wordpress//wordpress-controller.js?id=' . $id . '"></script>
            <script type="text/javascript" src="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'src/model/game.js?id=' . $id . '"></script>
            <link rel="stylesheet" type="text/css" href="' . plugins_url($this->plugin_name . "/api/", $this->plugin_name) . 'css/dhtml-chess-all.css?id=' . $id . '">
           
           ';


if ($dhtml_chess_debug) {
    echo $content;

} else {

    wp_enqueue_style($this->plugin_name . "css", plugin_dir_url(__FILE__) . '../../api/css/dhtml-chess-all.css', array(), $this->version, 'all');
    wp_enqueue_script($this->plugin_name . "js", plugin_dir_url(__FILE__) . '../../api/js/dhtml-chess.js', array("jquery"), $this->version, false);
    wp_enqueue_script($this->plugin_name . "stockfish", plugin_dir_url(__FILE__) . '../../api/src/controller/stockfish-engine-controller.js?', array("jquery"), $this->version, false);
    wp_enqueue_script($this->plugin_name . "editor", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-editor-minified.js', array("jquery"), $this->version, false);
    wp_enqueue_script($this->plugin_name . "imp2", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-controller.js', array("jquery"), $this->version, false);
    wp_enqueue_script($this->plugin_name . "imp3", plugin_dir_url(__FILE__) . '../../api/src/wordpress/editor.js', array("jquery"), $this->version, false);
    wp_enqueue_script($this->plugin_name . "imp", plugin_dir_url(__FILE__) . '../../api/src/wordpress/import-pgn-dialog.js', array("jquery"), $this->version, false);

}

?>
<style type="text/css">
    .ludo-view input[type=radio], .ludo-view input[type=checkbox] {
        width: 12px !important;
        background-color: transparent;
    }

    .ludo-list-item-front {
        background-color: #555;
    }


    .ludo-list-item{
        overflow: hidden;
        border:1px solid #444;
        border-radius:2px;
        margin:2px;
    }
    .ludo-list-item-front{
        background-color:#555;
    }

    .ludo-list-item-front,.ludo-list-item-back{
        font-size:12px;
    }
    .ludo-list-item-front > div, .ludo-list-item-back > div{
        padding:5px;
    }

    .ludo-view{

    }

    .pgn_list_pgn_id{
        right:2px;
        top:2px;
        padding:5px;
        position:absolute;
        background-color:#1976D2;
        border-radius:5px;
        color:#FFF;
    }

    .game_id{
        right:2px;
        top:2px;
        padding:5px;
        position:absolute;
        background-color:#1976D2;
        border-radius:5px;
        color:#FFF;
    }

    .pgn_list_item{
        height:65px;
        position:relative;
    }
    .pgn_list_updated{
        font-size:0.8em;
    }
    .pgn_list_name{
        font-size:1.1em;
    }
    /**
            return '<div class="pgn_list_item">'
                + '<div class="pgn_list_name"><strong>' + record.pgn_name + '</strong></div>'
                + '<div class="pgn_list_pgn_id">ID: ' + record.id + '</div>'
                + '<div class="pgn_list_updated">Updated: ' + record.updated + '</div>'
                + '<div class="pgn_list_count_games">Games: ' + record.count + '</div>'
                + '</div>';
    */

    .ludo-tab-strip-tab span{
        font-size:13px !important;
    }

    .ludo-window > .ludo-body{
        font-size:13px !important;
    }

    .ludo-chess-view-metadata-game{
        font-size:14px;
    }

    .dhtml-chess-comp-eval{
        margin-top:5px;
    }

    .dhtml-chess-comp-eval-group{
        display:inline-block;
        margin-right:8px;
    }
    .dhtml-chess-comp-eval-notation{
        color:#FFF;
        display:inline-block;
        padding-right:4px;
    }

    .dhtml-chess-comp-eval-score{
        font-size:1.1em;
        font-weight:bold;
        color:#FFF;
        display:inline-block;
        margin-right:10px;
    }

    .dhtml-chess-comp-eval-mn{
        color:#000;
        font-size:1.1em;
        font-weight:bold;
    }
    

</style>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<div id="dhtml_chess-editor" style="width:100%;height:100%"></div>
<script type="text/javascript">
    jQuery(document).ready(function () {
        ludo.config.setUrl(window.ajaxurl);
        ludo.config.setDocumentRoot('<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>');
        new chess.WPEditor({
            renderTo: '#dhtml_chess-editor'
        })

    });
</script>