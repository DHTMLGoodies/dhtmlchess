<?php
/**
 * Created by IntelliJ IDEA.
 * User: alfmagne1
 * Date: 01/02/2017
 * Time: 20:40
 */

wp_enqueue_style($this->plugin_name . "css", plugin_dir_url(__FILE__) . '../../api/css/dhtml-chess-all.css', array(), $this->version, 'all');
wp_enqueue_script($this->plugin_name . "js", plugin_dir_url(__FILE__) . '../../api/js/dhtml-chess.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "stockfish", plugin_dir_url(__FILE__) . '../../api/src/controller/stockfish-engine-controller.js?', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "editor", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-editor-minified.js', array("jquery"), $this->version, false);
wp_enqueue_script($this->plugin_name . "archived", plugin_dir_url(__FILE__) . '../../api/src/wordpress/wordpress-archived.js', array("jquery"), $this->version, false);

?>
<style type="text/css">
    .ludo-view input[type=radio], .ludo-view input[type=checkbox] {
        width: 12px !important;
        background-color: transparent;
    }

    .ludo-list-item-front {
        background-color: #555;
    }


    .ludo-list-item{
        overflow: hidden;
        border:1px solid #444;
        border-radius:2px;
        margin:2px;
    }
    .ludo-list-item-front{
        background-color:#555;
    }

    .ludo-list-item-front,.ludo-list-item-back{
        font-size:12px;
    }
    .ludo-list-item-front > div, .ludo-list-item-back > div{
        padding:5px;
    }

    .ludo-view{

    }

    .pgn_list_pgn_id{
        right:2px;
        top:2px;
        padding:5px;
        position:absolute;
        background-color:#1976D2;
        border-radius:5px;
        color:#FFF;
    }

    .game_id{
        right:2px;
        top:2px;
        padding:5px;
        position:absolute;
        background-color:#1976D2;
        border-radius:5px;
        color:#FFF;
    }

    .pgn_list_item{
        height:65px;
        position:relative;
    }
    .pgn_list_updated{
        font-size:0.8em;
    }
    .pgn_list_name{
        font-size:1.1em;
    }
    /**
            return '<div class="pgn_list_item">'
                + '<div class="pgn_list_name"><strong>' + record.pgn_name + '</strong></div>'
                + '<div class="pgn_list_pgn_id">ID: ' + record.id + '</div>'
                + '<div class="pgn_list_updated">Updated: ' + record.updated + '</div>'
                + '<div class="pgn_list_count_games">Games: ' + record.count + '</div>'
                + '</div>';
    */

    .ludo-tab-strip-tab span{
        font-size:13px !important;
    }

    .ludo-window > .ludo-body{
        font-size:13px !important;
    }

    .ludo-chess-view-metadata-game{
        font-size:14px;
    }

    .dhtml-chess-comp-eval{
        margin-top:5px;
    }

    .dhtml-chess-comp-eval-group{
        display:inline-block;
        margin-right:8px;
    }
    .dhtml-chess-comp-eval-notation{
        color:#FFF;
        display:inline-block;
        padding-right:4px;
    }

    .dhtml-chess-comp-eval-score{
        font-size:1.1em;
        font-weight:bold;
        color:#FFF;
        display:inline-block;
        margin-right:10px;
    }

    .dhtml-chess-comp-eval-mn{
        color:#000;
        font-size:1.1em;
        font-weight:bold;
    }

</style>
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <h4><?php echo __("Swipe right to restore, Swipe left to permanently delete", $this->plugin_name); ?></h4>
    <div class="ludo-twilight" style="height:500px" id="archived-list"></div>
    <script type="text/javascript">

        jQuery(document).ready(function () {
            ludo.config.setUrl(window.ajaxurl);
            ludo.config.setDocumentRoot('<?php echo plugins_url($this->plugin_name . "/api/", $this->plugin_name); ?>');
            new chess.wordpress.WordPressArchived({
                renderTo: '#archived-list',
                layout: {
                    width: 'matchParent', height: 'matchParent'
                }
            })

        });


    </script>
    <p><?php echo __("Databases can be archived from the editor by swiping right from the database list", $this->plugin_name); ?></p>

</div>