<?php
$license = get_option("wordpresschess_license_key");
$status = get_option("wordpresschess_license_status");

?>

<div class="wrap">

	<h2><?php echo esc_html(get_admin_page_title()); ?></h2>
	<form method="post" name="dhtmlchess_options" action="options.php">
		<?php
		do_settings_sections($this->plugin_name);
		settings_fields($this->plugin_name);


		?>
		<fieldset class="dhtml-chess-admin-fieldset">
			<legend><?php echo __('License Key'); ?></legend>
			<table class="form-table">
				<tbody>
				<tr valign="top">
					<th scope="row" valign="top">
						<?php _e('License Key'); ?>
					</th>
					<td>
						<input id="wordpresschess_license_key" name="wordpresschess_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license ); ?>" />
						<label class="description" for="wordpresschess_license_key"><?php _e('Enter your license key'); ?></label>
					</td>
				</tr>
				<?php if( false !== $license ) { ?>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php _e('Activate License'); ?>
						</th>
						<td>
							<?php if( $status !== false && $status == 'valid' ) { ?>
								<span style="color:green;"><?php _e('active'); ?></span>
								<?php wp_nonce_field( 'wordpresschess_nonce', 'wordpresschess_nonce' ); ?>
								<input type="submit" class="button-secondary" name="wordpresschess_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
							<?php } else {
								wp_nonce_field( 'wordpresschess_nonce', 'wordpresschess_nonce' ); ?>
								<input type="submit" class="button-secondary" name="wordpresschess_license_activate" value="<?php _e('Activate License'); ?>"/>
							<?php } ?>
						</td>
					</tr>
				<?php } ?>
				</tbody>
			</table>
		</fieldset>
		<?php submit_button(__('Save all changes', $this->plugin_name), 'primary', 'submit', TRUE); ?>
	</form>
</div>