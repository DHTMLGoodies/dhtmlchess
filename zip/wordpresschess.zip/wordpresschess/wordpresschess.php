<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://www.dhtmlchess.com
 * @since             1.0.0
 * @package           Wordpresschess
 *
 * @wordpress-plugin
 * Plugin Name:       WordPressChess
 * Plugin URI:        http://wordpresschess.com
 * Description:       Display Chess Games and Chess tactic puzzles on your website.
 * Version:           1.0.55
 * Author:            dhtmlchess.com
 * Author URI:        http://www.dhtmlchess.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wordpresschess
 * Domain Path:       /languages
 */

define( "WORDPRESSCHESS_VERSION", "1.0.55" );
if ( ! defined( "WORDPRESSCHESS_PRO" ) ) {
	define( "WORDPRESSCHESS_PRO", true );
}

// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'WORDPRESSCHESS_SL_STORE_URL', 'https://wordpresschess.com' ); // IMPORTANT: change the name of this constant to something unique to prevent conflicts with other plugins using this system
// the name of your product. This is the title of your product in EDD and should match the download title in EDD exactly
define( 'WORDPRESSCHESS_SL_ITEM_NAME', 'WordPressChess PRO' ); // IMPORTANT: change the name of this constant to something unique to prevent conflicts with other plugins using this system
define( 'WORDPRESSCHESS_LICENSE_PAGE', 'wordpresschess_top_menu' );

if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	// load our custom updater if it doesn't already exist
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

function wordpresschess_sl_sample_plugin_updater() {

	// retrieve our license key from the DB
	$license_key = trim( get_option( 'wordpresschess_license_key' ) );

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WORDPRESSCHESS_SL_STORE_URL, __FILE__, array(
			'version'   => '1.0.54',                // current version number
			'license'   => $license_key,        // license key (used get_option above to retrieve from DB)
			'item_name' => WORDPRESSCHESS_SL_ITEM_NAME,    // name of this plugin
			'author'    => 'WordPressChess.com',  // author of this plugin
			'beta'      => false
		)
	);

}

add_action( 'admin_init', 'wordpresschess_sl_sample_plugin_updater', 0 );
# add_action( 'admin_init', 'wordpresschess_sample_register_option' );


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


add_option( "dhtml_chess_db_version", 1 );
add_option( "dhtml_chess_db_installed_2", 0 );


// Update this when database changes has been done
$dhtml_chess_db_version = 3;

require_once plugin_dir_path( __FILE__ ) . 'api/autoload.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wordpresschess-activator.php
 */
function activate_wordpresschess() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpresschess-activator.php';
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpresschess-upgrade.php';
	Wordpresschess_Activator::activate();
}

function uninstall_wordpresschess() {

	$options             = get_option( "wordpresschess" );
	$remove_on_uninstall = isset( $options["remove_on_uninstall"] ) ? $options["remove_on_uninstall"] : '0';

	if ( $remove_on_uninstall == '1' ) {
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpresschess-uninstall.php';
		# Dhtml_chess_Uninstall::uninstall();
	}
}

function wordpress_chess_update_db_check() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpresschess-upgrade.php';
	Wordpresschess_Upgrade::upgrade();
}

register_activation_hook( __FILE__, 'activate_wordpresschess' );
# register_deactivation_hook(__FILE__, 'deactivate_wordpresschess');
register_uninstall_hook( __FILE__, 'uninstall_wordpresschess' );
add_action( 'plugins_loaded', 'wordpress_chess_update_db_check' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wordpresschess.php';


add_action( 'admin_post_wordpresschess_import_pgn', 'wpc_import_pgn' );
add_action( 'wp_ajax_get_standings', 'wpc_get_standings' );
add_action( 'wp_ajax_get_standings_html', 'wpc_get_standings_html' );
add_action( 'wp_ajax_nopriv_get_standings', 'wpc_get_standings' );
add_action( 'wp_ajax_count_games', 'wpc_count_games' );
add_action( 'wp_ajax_get_draft', 'wpc_get_draft' );
add_action( 'wp_ajax_discard_draft', 'wpc_discard_draft' );
add_action( 'wp_ajax_save_draft', 'wpc_save_draft' );
add_action( 'wp_ajax_list_drafts', 'wpc_list_drafts' );
add_action( 'wp_ajax_random_game', 'wpc_random_game' );
add_action( 'wp_ajax_nopriv_random_game', 'wpc_random_game' );
add_action( 'wp_ajax_game_by_index', 'wpc_game_by_index' );
add_action( 'wp_ajax_nopriv_game_by_index', 'wpc_game_by_index' );
add_action( 'wp_ajax_game_by_id', 'wpc_game_by_id' );
add_action( 'wp_ajax_nopriv_game_by_id', 'wpc_game_by_id' );
add_action( 'wp_ajax_list_pgns', 'wpc_list_pgns' );
add_action( 'wp_ajax_nopriv_list_pgns', 'wpc_list_pgns' );
add_action( 'wp_ajax_list_of_games', 'wpc_list_of_games' );
add_action( 'wp_ajax_nopriv_list_of_games', 'wpc_list_of_games' );
add_action( 'wp_ajax_nopriv_download_pgn', 'wpc_download_pgn' );
add_action( 'wp_ajax_delete_game', 'wpc_delete_game' );
add_action( 'wp_ajax_save_game', 'wpc_save_game' );
add_action( 'wp_ajax_publish_game', 'wpc_publish_game' );
add_action( 'wp_ajax_archive_pgn', 'wpc_archive_pgn' );
add_action( 'wp_ajax_new_pgn', 'wpc_new_pgn' );
add_action( 'wp_ajax_list_archived', 'wpc_list_archived' );
add_action( 'wp_ajax_restore_pgn', 'wpc_restore_pgn' );
add_action( 'wp_ajax_delete_pgn', 'wpc_delete_pgn' );
add_action( 'wp_ajax_rename_pgn', 'wpc_rename_pgn' );
add_action( 'wp_ajax_import_pgn_string', 'wpc_import_pgn_string' );


$start_time = microtime( true );


function canEditWordPressChess() {
	return true;
}


function wpc_import_pgn() {

	/*
	 * {"pgn":{"name":"art_attack.pgn","type":"application\/octet-stream","tmp_name":"\/private\/var\/tmp\/phpGyfato","error":0,"size":60118}}
	 */
	if ( canEditWordPressChess() && isset( $_FILES['pgn'] ) ) {

		check_admin_referer( 'wordpresschess_importpgn', '_nonce_wordpresschess' );

		try {
			$pgn = $_FILES['pgn'];

			if ( empty( $_FILES['pgn'] ) || empty( $pgn["tmp_name"] ) ) {
				throw new DhtmlChessException( "No file" );
			}
			$name = empty( $_POST['pgn_title'] ) ? $pgn["name"] : $_POST['pgn_title'];

			$pgnContent = file_get_contents( $pgn["tmp_name"] );
			$importer   = new DhtmlChessImportPgn();
			$pgn        = $importer->importPgnStringToNewDatabase( $name, $pgnContent );

			if ( ! empty( $pgn ) ) {
				if ( wp_redirect( admin_url( esc_url_raw( 'admin.php?page=wordpresschess_import_pgn&m=' . $pgn->getName() . "&pgn_id=" . $pgn->getId() ) ) ) ) {
					exit;
				};
			}

		} catch ( DhtmlChessException $e ) {
			if ( wp_redirect( admin_url( esc_url_raw( 'admin.php?page=wordpresschess_import_pgn&e=1&msg=' . $e->getMessage() ) ) ) ) {
				exit;
			};

		}

		if ( wp_redirect( admin_url( esc_url_raw( 'admin.php?page=wordpresschess_import_pgn&e=1' ) ) ) ) {
			exit;
		};
	}
	wp_die();
}


/**
 * @param DhtmlChessException $exception
 */
function wpc_outputError( $exception ) {
	header( "content-type: Application/json" );
	$message = "Error: " . $exception->getMessage();
	$data    = array( "success" => false, "response" => $message );
	echo json_encode( $data );
}

function wpc_outputContent( $jsonString ) {
	header( "content-type: Application/json" );
	global $start_time;
	$elapsed = microtime( true ) - $start_time;

	echo '{"success" : true, "time": ' . $elapsed . ', "response":' . $jsonString . '}';
}

function wpc_get_standings_html() {
	if ( ! isset( $_POST['pgn'] ) ) {
		throw new DhtmlChessException( "Missing pgn attribute" );
	}
	$views = new DhtmlChessViews();
	echo $views->standingsAsHTML( $_POST['pgn'], false );
	wp_die();
}

function wpc_get_standings() {
	if ( ! isset( $_POST['pgn'] ) ) {
		throw new DhtmlChessException( "Missing pgn attribute" );
	}
	$db = new DhtmlChessDatabase();
	wpc_outputContent( $db->getStandings( $_POST["pgn"] ) );
	wp_die();
}

function wpc_download_pgn() {
	if ( isset( $_POST["game"] ) ) {
		try {
			$db   = new DhtmlChessDatabase();
			$game = $db->gameById( $_POST["game"] );
			if ( empty( $game ) ) {
				throw new DhtmlChessException( "Unable to locate pgn" );
			}
			$parser = new JsonToPgnParser();
			$parser->addGame( $game );
			wpc_outputContent( $parser->asPgn() );
		} catch ( DhtmlChessException $e ) {
			wpc_outputError( $e );
		}
	}
	wp_die();
}


function wpc_list_drafts() {
	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->allDrafts() );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_count_games() {
	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->countGamesInDatabase() );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_get_draft() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( ! isset( $_POST['draft_id'] ) ) {
			throw new DhtmlChessException( "Missing draft_id" );
		}
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->getDraft( $_POST['draft_id'] ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_list_archived() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->listOfArchivedPgns() );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_restore_pgn() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( empty( $_POST['pgn'] ) ) {
			throw new DhtmlChessException( "PGN not set" );
		}

		$pgnId = preg_replace( "/[^0-9]/si", "", $_POST["pgn"] );
		if ( empty( $pgnId ) ) {
			throw new DhtmlChessException( "Invalid pgn id" );
		}

		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->restoreArchived( $pgnId ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_import_pgn_string() {
	if ( isset( $_POST['pgn_id'] ) && isset( $_POST['pgn'] ) ) {
		try {
			$db            = new DhtmlChessDatabase();
			$response      = $db->appendPgnString( $_POST['pgn_id'], $_POST['pgn'] );
			$countImported = $response[0];
			$total         = $response[1];
			if ( $countImported == 0 ) {
				throw new DhtmlChessException( "No games imported" );
			}
			$array = array( 'imported' => $countImported, 'total' => $total );
			$json  = json_encode( $array );
			wpc_outputContent( $json );
		} catch ( DhtmlChessException $e ) {
			wpc_outputError( $e );
		}
	}

	wp_die();
}


function wpc_rename_pgn() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( empty( $_POST['pgn'] ) ) {
			throw new DhtmlChessException( "PGN not set" );
		}
		if ( empty( $_POST['name'] ) ) {
			throw new DhtmlChessException( "PGN not set" );
		}

		$newName = trim( $_POST['name'] );

		$pgnId = preg_replace( "/[^0-9]/si", "", $_POST["pgn"] );
		if ( empty( $pgnId ) ) {
			throw new DhtmlChessException( "Invalid pgn id" );
		}

		$db  = new DhtmlChessDatabase();
		$pgn = $db->rename( $pgnId, $newName );
		wpc_outputContent( $pgn->asJSON() );

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_delete_pgn() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( empty( $_POST['pgn'] ) ) {
			throw new DhtmlChessException( "PGN not set" );
		}

		$pgnId = preg_replace( "/[^0-9]/si", "", $_POST["pgn"] );
		if ( empty( $pgnId ) ) {
			throw new DhtmlChessException( "Invalid pgn id" );
		}

		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->deletePgn( $pgnId ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}


function wpc_new_pgn() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( ! isset( $_POST['pgn_name'] ) ) {
			throw new DhtmlChessException( "Missing pgn name" );
		}
		$db  = new DhtmlChessDatabase();
		$pgn = $db->createDatabase( $_POST['pgn_name'] );

		wpc_outputContent( $pgn->getId() );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}

function wpc_archive_pgn() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( ! isset( $_POST['pgn'] ) ) {
			throw new DhtmlChessException( "Missing pgn" );
		}

		$db  = new DhtmlChessDatabase();
		$pgn = preg_replace( "/[^0-9]/si", "", $_POST['pgn'] );
		if ( empty( $pgn ) ) {
			throw new DhtmlChessException( "Missing pgn" );
		}
		$success = $db->archivePgn( $pgn );
		if ( $success ) {
			wpc_outputContent( $success );
		} else {
			throw new DhtmlChessException( "Unable to archive - no rows updated" );
		}

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_discard_draft() {

	try {
		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		$draftId = ! empty( $_POST['draft_id'] ) ? $_POST['draft_id'] : '';

		$draftId = preg_replace( "/[^0-9]/si", "", $draftId );

		if ( empty( $draftId ) ) {
			throw new DhtmlChessException( "Unable to delete - draft_id missing" );
		}

		$db           = new DhtmlChessDatabase();
		$countDeleted = $db->deleteDraft( $draftId );

		if ( $countDeleted > 0 ) {
			wpc_outputContent( $countDeleted );
		} else {
			throw new DhtmlChessException( "Could not find draft_id" );
		}

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}

	wp_die();
}

function wpc_publish_game() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		if ( ! isset( $_POST['pgn'] ) ) {
			throw new DhtmlChessException( "Missing destination pgn" );
		}
		if ( ! isset( $_POST['game'] ) ) {
			throw new DhtmlChessException( "Missing game" );
		}

		$game = stripslashes( $_POST['game'] );
		$game = json_decode( $game, true );
		$db   = new DhtmlChessDatabase();
		$id   = $db->publishDraft( json_encode( $game ), $_POST['pgn'] );


		wpc_outputContent( $id );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}


function wpc_save_game() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		$db = new DhtmlChessDatabase();

		if ( ! isset( $_POST['game'] ) ) {
			throw new DhtmlChessException( "Game data missing" );

		}


		$game = $_POST['game'];
		$game = stripslashes( $game );
		$game = json_decode( $game, true );

		if ( ! empty( $_POST['pgn'] ) ) {
			$pgn = $_POST['pgn'];
		} else {
			$pgn = isset( $game['pgn'] ) ? $game['pgn'] : null;
		}

		if ( empty( $pgn ) ) {
			throw new DhtmlChessException( "Name of pgn for game to saved missing" );
		}

		$db->updateGame( $pgn, json_encode( $game ) );


		wpc_outputContent( $game['id'] );

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}


function wpc_save_draft() {
	try {

		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access Denied" );
		}

		$game     = stripslashes( $_POST['game'] );
		$game     = json_decode( $game, true );
		$db       = new DhtmlChessDatabase();
		$draftId  = $db->saveDraft( json_encode( $game ) );
		$response = array( "draft_id" => $draftId );

		wpc_outputContent( json_encode( $response ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();

}


function wpc_random_game() {

	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->randomGame( $_POST["pgn"] ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_list_of_games() {
	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->listOfGames( $_POST["pgn"] ) );
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_game_by_index() {


	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->gameByIndex( $_POST["pgn"], $_POST["index"] ) );

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_game_by_id() {
	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->gameById( $_POST["id"] ) );

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}

function wpc_list_pgns() {
	try {
		$db = new DhtmlChessDatabase();
		wpc_outputContent( $db->listOfPgns() );

	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}


function wpc_delete_game() {
	try {
		if ( ! canEditWordPressChess() ) {
			throw new DhtmlChessException( "Access denied" );
		} else {
			if ( ! isset( $_POST['pgn'] ) ) {
				throw new DhtmlChessException( "Missing pgn attribute" );
			}
			if ( ! isset( $_POST['id'] ) ) {
				throw new DhtmlChessException( "Missing id" );
			}

			$db    = new DhtmlChessDatabase();
			$count = $db->deleteGame( $_POST['pgn'], $_POST["id"] );

			return json_encode( array( "success" => $count > 0 ) );
		}
	} catch ( DhtmlChessException $e ) {
		wpc_outputError( $e );
	}
	wp_die();
}


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wordpresschess() {

	$plugin = new Wordpresschess();
	$plugin->run();

}

run_wordpresschess();
