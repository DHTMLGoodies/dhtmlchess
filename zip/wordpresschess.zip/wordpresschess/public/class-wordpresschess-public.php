<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.dhtmlchess.com
 * @since      1.0.0
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordpresschess
 * @subpackage Wordpresschess/public
 * @author     Alf Magne Kalleland <alf.magne.kalleland@gmail.com>
 */
class Wordpresschess_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $this ->plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	private $dhtml_chess_options;

	private $config_added = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 *
	 * @param      string $this ->plugin_name The name of the plugin.
	 * @param      string $version The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->dhtml_chess_options = get_option( $this->plugin_name );

	}

	function addShortCodes() {

		wp_enqueue_script( "jquery" );
		add_shortcode( "fen", array( $this, "shortcode_handler" ) );
		add_shortcode( "pgn", array( $this, "shortcode_handler" ) );
		add_shortcode( "chess", array( $this, "shortcode_handler" ) );
		add_shortcode( "pgnignore", array( $this, "shortcode_handler" ) );
		add_shortcode( "fenignore", array( $this, "shortcode_handler" ) );
		add_shortcode( "chessignore", array( $this, "shortcode_handler" ) );
	}


	private function getLanguage() {
		$jsWords = array();
		$words   = array(
			"Add comment",
			"Add comment after",
			"Add comment before",
			"Annotate",
			"Append Line",
			"Archive Database",
			"Are you sure you want to discard this draft?",
			"Black",
			"Cancel",
			"Castling",
			"Clear",
			"Computer Eval",
			"Could not load game. Try again later",
			"Database",
			"Date",
			"Delete",
			"Delete Move",
			"Discard",
			"Discard draft",
			"Draft Saved",
			"Draft discarded",
			"Edit metadata",
			"En passant",
			"Engine stopped",
			"Event",
			"Everything is up to date",
			"FEN",
			"From elo",
			"Game",
			"Game Comment",
			"Game Drafts",
			"Game Saved",
			"Game published",
			"Game saved successfully",
			"Games",
			"Games in Database: ",
			"Good job! You have solved this puzzle. Click OK to load next game",
			"Good move",
			"Hint",
			"Import games(PGN)",
			"Invalid Fen",
			"Invalid game",
			"Invalid grade",
			"Invalid move",
			"Invalid position",
			"Last moves",
			"Load fen",
			"Loading drafts...",
			"Loading game",
			"Loading games...",
			"Metadata",
			"Move updated to",
			"Moving",
			"Name of new database",
			"New Database",
			"New Database created",
			"New Game",
			"New Game Database",
			"New Position",
			"Next Game",
			"No Databases found",
			"No Drafts Found",
			"No games",
			"OK",
			"Overwrite",
			"PGN Databases",
			"PGN archived",
			"PGN deleted",
			"PGN restored",
			"PGN:",
			"Paste fen into the text box below",
			"Player Black",
			"Player White",
			"Ply",
			"Poor move",
			"Position setup",
			"Publish",
			"Publish Game",
			"Publish game in",
			"Questionable move",
			"Rated",
			"Restore",
			"Result",
			"Round",
			"Save",
			"Save Draft",
			"Save Eval",
			"Save game",
			"Search",
			"Select PGN",
			"Selected",
			"Side to move",
			"Site",
			"Solution",
			"Speculative move",
			"Standings",
			"Start",
			"StockFish.JS Engine",
			"Time",
			"To elo",
			"Undo",
			"Update",
			"Variation",
			"Very good move",
			"Very poor move",
			"Well done - Puzzle complete",
			"White",
			"Wrong move - please try again",
			"You have unsaved game data. Do you want to discard these?",
			"commandWelcome",
			"command_",
			"to move"
		);
		foreach ( $words as $word ) {
			$jsWords[] = 'dl["' . $word . '"] = "' . __( $word, "dhtml_chess" ) . '";';
		}
		$content = '<script type="text/javascript">jQuery(document).ready(function(){var dl = chess.language;' . implode( "", $jsWords ) . '});</script>';

		return $content;
	}


	function shortcode_handler( $attributes, $content = null, $tag ) {

		try {


			if ( strstr( $tag, "ignore" ) || ( ! empty( $attributes ) && isset( $attributes["ignore"] ) ) ) {

				$tag = str_replace( "ignore", "", $tag );
				$ret = '[' . $tag;

				foreach ( $attributes as $key => $val ) {
					if ( $key != "ignore" ) {
						$ret .= ' ' . $key . '="' . $val . '"';
					}
				}

				$ret .= ']';

				if ( ! empty( $content ) ) {
					$ret .= $content . '[/' . $tag . ']';
				}

				return $ret;
			}

			if ( ( $tag == "fen" || $tag == "pgn" ) && empty( $content ) ) {
				return '[' . $tag . ' "' . implode( ",", $attributes ) . '"]';
			}

			$options          = get_option( $this->plugin_name );
			$default_game_tpl = isset( $options["default_game_tpl"] ) ? $options["default_game_tpl"] : 1;
			$default_db_tpl   = isset( $options["default_db_tpl"] ) ? $options["default_db_tpl"] : 1;
			$arrow_styles     = isset( $options["arrow_styles"] ) ? $options["arrow_styles"] : "";

			$theme = ! empty( $options['theme'] ) ? $options['theme'] : "grey";

			wp_localize_script( 'ajax-script', 'ajax_object', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'we_value' => 1234
			) );

			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . '../api/css/dhtml-chess-wordpress-minified.css', array(), $this->version, 'all' );
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . '../api/js/dhtml-chess-wordpress-minified.js', array( "jquery" ), $this->version, false );
			wp_enqueue_style( $this->plugin_name . 'override', plugin_dir_url( __FILE__ ) . '../api/themes/overrides.css', array(), $this->version, 'all' );
			wp_enqueue_style( $this->plugin_name . 'themecss', plugin_dir_url( __FILE__ ) . '../api/themes/' . $theme . '.css', array(), $this->version, 'all' );
			wp_enqueue_script( $this->plugin_name . "theme", plugin_dir_url( __FILE__ ) . '../api/themes/' . $theme . '.js', array(), $this->version, false );

			/*
			wp_enqueue_script($this->plugin_name . "1", plugin_dir_url(__FILE__) . '../api/src/wp-public/wordpress-templates-minified.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "2", plugin_dir_url(__FILE__) . '../api/src/controller/play-stockfish-controller.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "3", plugin_dir_url(__FILE__) . '../api/src/controller/computer-controller.js', array(), $this->version, false);

			wp_enqueue_script($this->plugin_name . "11", plugin_dir_url(__FILE__) . '../api/src/wp-public/wp-template.js', array(), $this->version, false);

			wp_enqueue_script($this->plugin_name . "12", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game-template.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "13", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game1.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "14", plugin_dir_url(__FILE__) . '../api/src/view/buttonbar/bar.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "15", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game2.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "16", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game3.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "17", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game4.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "18", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game5.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "19", plugin_dir_url(__FILE__) . '../api/src/view/board/side-to-move.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "20", plugin_dir_url(__FILE__) . '../api/src/wp-public/fen/wp-fen.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "21", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game6.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "22", plugin_dir_url(__FILE__) . '../api/src/wp-public/pgn/viewer-template.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "23", plugin_dir_url(__FILE__) . '../api/src/wp-public/pgn/viewer1.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "24", plugin_dir_url(__FILE__) . '../api/src/wp-public/pgn/viewer2.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "25", plugin_dir_url(__FILE__) . '../api/src/wp-public/pgn/viewer3.js', array(), $this->version, false);
			# wp_enqueue_script($this->plugin_name . "3", plugin_dir_url(__FILE__) . '../api/src/sound/sound.js', array(), $this->version, false);
			*/
			/*
			wp_enqueue_script($this->plugin_name . "2", plugin_dir_url(__FILE__) . '../api/src/view/board/piece.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "3", plugin_dir_url(__FILE__) . '../api/src/view/board/board.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "4", plugin_dir_url(__FILE__) . '../api/src/view/highlight/square-pool.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "6", plugin_dir_url(__FILE__) . '../api/src/view/highlight/arrow-pool.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "5", plugin_dir_url(__FILE__) . '../api/src/view/board/board-interaction.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "21", plugin_dir_url(__FILE__) . '../api/src/view/notation/last-comment.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "22", plugin_dir_url(__FILE__) . '../api/src/view/buttonbar/bar.js', array(), $this->version, false);


			#wp_enqueue_script($this->plugin_name . "2", plugin_dir_url(__FILE__) . '../api/src/wp-public/special/pinned.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "7", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game1.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "8", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game2.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "9", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game3.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "10", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game4.js', array(), $this->version, false);
			wp_enqueue_script($this->plugin_name . "11", plugin_dir_url(__FILE__) . '../api/src/wp-public/game/game5.js', array(), $this->version, false);
			*/

			if ( empty( $attributes ) ) {
				$attributes = array();
			}

			$attributes["_p"] = 1; // PRO feature attribute

			if ( ! empty( $attributes["standings"] ) ) {
				$attributes["leaderboard"] = 1;
			}
			if ( $tag == "chess" && ! empty( $attributes["leaderboard"] ) && ! empty( $attributes["tpl"] ) && $attributes["tpl"] == 2 && ! empty( $attributes["db"] ) ) {
				$handler    = new DhtmlChessViews();
				$sofiaRules = ! empty( $attributes["sofiaRules"] ) ? $attributes["sofiaRules"] : false;

				return $handler->standingsAsHTML( $attributes["db"], $sofiaRules );
			}

			$prefix = "";
			if ( ! $this->config_added ) {
				$this->config_added = true;
				$pieces             = ! empty( $options['pieces'] ) ? $options['pieces'] : "svg_bw";

				$prefix = $this->getLanguage() . '<script type="text/javascript">
            // Chess For Wordpress www.dhtmlchess.com
            jQuery(document).ready(function(){
                    if(chess.THEME)chess.THEME["chess.view.board.Board"].pieceLayout="' . $pieces . '";
                    chess.OVERRIDES = {
                        arrow_styles : "' . $arrow_styles . '"
                    };
                    ludo.config.setUrl("' . admin_url( 'admin-ajax.php' ) . '");
                    ludo.config.setDocumentRoot("' . plugins_url( $this->plugin_name . "/api/", $this->plugin_name ) . '/");
            });
            </script>';
			};

			$docRoot = plugins_url( $this->plugin_name . "/api/", $this->plugin_name );
			$handler = new DhtmlChessViews();


			if ( empty( $attributes["tpl"] ) ) {
				if($tag == 'fen'){
					$attributes["tpl"] = 6;
				}
				else if ( isset( $attr["game"] ) || $tag == "pgn" ) {
					$attributes["tpl"] = $default_game_tpl;
				} elseif ( isset( $attr["db"] ) && ! isset( $attr["tactics"] ) ) {
					$attributes["tpl"] = $default_db_tpl;
				} else {
					$attributes["tpl"] = 1;
				}
			}

			if ( $tag == "fen" ) {
				$view = $handler->getParsedTagFromAttributes( "fen", $attributes, $content );

				return $prefix . $view->getJS( $docRoot );
			} else if ( $tag == "pgn" ) {
				$view = $handler->getParsedTagFromAttributes( "pgn", $attributes, $content );

				return $prefix . $view->getJS( $docRoot );
			} else {
				$view = $handler->getParsedTagFromAttributes( "chess", $attributes, $content );

				return $prefix . $view->getJS( $docRoot );
			}

		} catch ( Exception $e ) {
			$this->config_added = false;

			return "";
		}
	}


	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Dhtml_chess_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Dhtml_chess_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Dhtml_chess_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Dhtml_chess_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

	}

}
